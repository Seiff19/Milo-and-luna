# Milo & Luna - character consistency kit

Paste these descriptors VERBATIM into every prompt. Do not paraphrase them.

**Style lock:** Soft 2D watercolor storybook illustration, gentle wet-on-wet washes, soft blooming edges, visible cold-press paper grain, warm hand-painted feel, no text, no logos, 16:9 composition

**Negative prompt:** photorealistic, 3D render, CGI, harsh black outlines, text, captions, watermark, extra limbs, deformed rabbit anatomy, off-model characters, changed fur colors, different accessories

## Milo
Milo, a male rabbit with warm honey-tan fur, cream belly and muzzle, gentle round dark eyes, a soft kind expression, wearing a light-blue scarf

## Luna
Luna, a female rabbit with warm honey-tan fur (a touch lighter and creamier than Milo), cream chest, kind dark eyes with soft lashes, a pink ribbon bow tied on her left ear

## Age / outfit variants
- **young**: as a young bunny: small, round, big-headed, playful proportions
- **teen**: as a young adult rabbit: slimmer, longer ears, thoughtful
- **wedding**: as grown rabbits on their wedding day (Milo in a dove-grey suit with a small white flower on the lapel, no scarf for the ceremony; Luna in a white wedding gown with a sheer veil, her pink ribbon still on her ear, holding a small bouquet of pink and white flowers)
- **mature**: as mature rabbits: confident, calm, fur slightly lighter around the muzzle

## Workflow
1. Generate the 4 character sheets (stage `characters`). Review them; regenerate until Milo and Luna look right.
2. Generate keyframes (stage `keyframes`) using the sheets as reference images.
3. Animate each keyframe (stage `videos`, image-to-video).
4. If a character drifts off-model, regenerate that keyframe, not the video.


## act1 - Childhood Friendship (4 x 5s)

**Shot 1** - Wide shot: the two young rabbits meet in the middle of the meadow, noses almost touching, curious
- Motion: very slow push-in; dandelion seeds drift past; both rabbits tilt their heads and wiggle their noses

**Shot 2** - Both young rabbits hop side by side through tall grass and wildflowers, mid-hop, joyful
- Motion: gentle tracking pan following their hops; grass and flowers sway

**Shot 3** - Close-up: Luna blows a dandelion puff while Milo watches in delight, seeds floating in golden light
- Motion: slow drift; dandelion seeds float upward and across the frame

**Shot 4** - The two chase a butterfly across the meadow in golden backlight
- Motion: slow pull-back as they hop away toward a glowing horizon


## act2 - Learning & Growing Together (5 x 5s)

**Shot 1** - Wide shot: under the big blossoming oak, the two sit close with one large open book
- Motion: slow push-in; blossom petals fall gently

**Shot 2** - Medium shot: reading one big book side by side, Luna points at a page, Milo smiles
- Motion: subtle drift; a page edge flutters in the breeze

**Shot 3** - Detail: the open book with simple pencil sketches of stars and plants, two small paws pointing at the same line
- Motion: very slow tilt down the page; dust motes in warm light

**Shot 4** - They study a tiny leaf together with a small magnifying glass, heads touching
- Motion: gentle orbit; dappled light shifts through the leaves

**Shot 5** - Late afternoon: they lean shoulder to shoulder watching sunlight through the blossoms, content
- Motion: slow pull-back revealing the whole tree glowing


## act3 - Marriage & Settling Down (5 x 5s)

**Shot 1** - Meadow wedding: a floral arch of pink and white blossoms strung with warm fairy lights; Milo and Luna stand beneath it facing each other
- Motion: slow push-in; fairy lights twinkle; petals drift

**Shot 2** - Close-up: their paws joined beneath the arch, noses nearly touching, petals falling
- Motion: very slow drift; shallow soft focus; warm light flares

**Shot 3** - Small woodland friends (a mouse, a hedgehog, songbirds) cheer softly and toss petals as the couple stands under the arch
- Motion: gentle pan across the guests; petals in the air

**Shot 4** - Dusk: Milo and Luna walk paw in paw along a flower-lined path toward a cozy hillside burrow home
- Motion: slow tracking shot from behind; fireflies begin to appear

**Shot 5** - The cozy burrow home at golden hour: round green door, glowing windows, garden flowers; the couple stand in the doorway
- Motion: slow push-in; window light flickers warmly


## act4 - Mutual Growth & Partnership (5 x 5s)

**Shot 1** - Inside the burrow studio, Milo and Luna paint side by side on one large shared canvas
- Motion: slow push-in; sunlight slides across the floor

**Shot 2** - Close-up: Luna's brush adds a bright stroke while Milo watches and nods encouragingly
- Motion: gentle drift between the two; paint shimmer

**Shot 3** - They hold up a finished painting of their meadow, proud and smiling
- Motion: slow pull-back; warm light blooms

**Shot 4** - Luna rests a paw on Milo's shoulder as he hesitates at a blank canvas; he smiles and begins to paint
- Motion: slow orbit; soft light

**Shot 5** - Evening: the two hang their paintings along the burrow wall by warm lamplight, content
- Motion: slow lateral pan along the wall of paintings


## act5 - Sudden Loss (4 x 5s)

**Shot 1** - A dim burrow room: one small glowing candle on a table and an empty wooden chair with a light-blue scarf draped over its back; no one else is there
- Motion: extremely slow push-in; candle flame flickers softly

**Shot 2** - Luna sits alone beside the candle, ears drooping, gazing at the empty chair, quiet grief
- Motion: extremely slow drift; the candle glow breathes

**Shot 3** - Close-up: the candle flame and the long shadow of the empty chair on the wall
- Motion: almost still; faint flicker; a few dust motes

**Shot 4** - Luna's paw gently rests on the light-blue scarf draped over the chair, eyes closed, cold blue window light
- Motion: nearly still, very slow push-in; slow fade-ready ending
