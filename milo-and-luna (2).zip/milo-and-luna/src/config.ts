// Single source of truth for timing. 30fps, 3450 frames = 115s.
export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;
export const FADE = 30; // crossfade length in frames (1s)
export const END_FADE = 45; // fade to black at the very end

export type ActId = "act1" | "act2" | "act3" | "act4" | "act5";

export type Camera = {
  scaleFrom: number;
  scaleTo: number;
  panX: [number, number]; // px
  panY: [number, number];
};

export type ActConfig = {
  id: ActId;
  title: string;
  from: number; // inclusive, absolute frame
  to: number; // exclusive
  camera: Camera;
  captionColor: string;
};

export const ACTS: ActConfig[] = [
  { id: "act1", title: "Childhood Friendship", from: 0, to: 600, camera: { scaleFrom: 1.04, scaleTo: 1.12, panX: [-20, 20], panY: [0, -10] }, captionColor: "#fff6e0" },
  { id: "act2", title: "Learning & Growing Together", from: 600, to: 1350, camera: { scaleFrom: 1.1, scaleTo: 1.03, panX: [24, -10], panY: [-6, 6] }, captionColor: "#fff6e0" },
  { id: "act3", title: "Marriage & Settling Down", from: 1350, to: 2100, camera: { scaleFrom: 1.03, scaleTo: 1.12, panX: [0, -24], panY: [8, -8] }, captionColor: "#fff1d6" },
  { id: "act4", title: "Mutual Growth & Partnership", from: 2100, to: 2850, camera: { scaleFrom: 1.05, scaleTo: 1.1, panX: [-16, 16], panY: [0, 0] }, captionColor: "#fff6e0" },
  // Act 5: very slow, subtle camera movement.
  { id: "act5", title: "Sudden Loss", from: 2850, to: 3450, camera: { scaleFrom: 1.02, scaleTo: 1.07, panX: [0, -8], panY: [0, 4] }, captionColor: "#cfd9ec" },
];

export const TOTAL_FRAMES = ACTS[ACTS.length - 1].to; // 3450

export type Caption = { from: number; to: number; text: string; color?: string };

export const CAPTIONS: Caption[] = [
  { from: 30, to: 270, text: "Once, in a meadow full of dandelions…" },
  { from: 300, to: 570, text: "…two small friends found each other." },
  { from: 650, to: 960, text: "They learned the world together." },
  { from: 1010, to: 1320, text: "Every page was better read side by side." },
  { from: 1410, to: 1710, text: "One golden evening, they promised forever." },
  { from: 1780, to: 2070, text: "Home became wherever the two of them were." },
  { from: 2150, to: 2460, text: "They made things — and made each other brave." },
  { from: 2520, to: 2820, text: "Every brushstroke, a quiet cheer." },
  { from: 2910, to: 3200, text: "Then, one quiet night, the chair was empty.", color: "#cfd9ec" },
  { from: 3230, to: 3410, text: "But the light he gave her is still lit.", color: "#cfd9ec" },
];

// Audio: fade in over 2s, fade out across Act 5 (95s -> 114s).
export const AUDIO = {
  src: "audio/ambient.mp3",
  baseVolume: 0.6,
  fadeInFrames: 60,
  fadeOutFrom: 2850,
  fadeOutTo: 3420,
};
