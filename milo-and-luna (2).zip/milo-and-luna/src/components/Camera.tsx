import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import type { Camera } from "../config";

/** Slow Ken Burns move over the life of the enclosing Sequence. */
export const CameraMove: React.FC<{ camera: Camera; length: number; children: React.ReactNode }> = ({ camera, length, children }) => {
  const frame = useCurrentFrame();
  const r = [0, Math.max(1, length)];
  const ease = (a: number, b: number) => interpolate(frame, r, [a, b], { extrapolateRight: "clamp" });
  const s = ease(camera.scaleFrom, camera.scaleTo);
  return (
    <AbsoluteFill style={{ transform: `translate(${ease(camera.panX[0], camera.panX[1])}px, ${ease(camera.panY[0], camera.panY[1])}px) scale(${s})`, transformOrigin: "50% 55%" }}>
      {children}
    </AbsoluteFill>
  );
};
