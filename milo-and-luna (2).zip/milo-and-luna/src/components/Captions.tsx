import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { CAPTIONS } from "../config";

/** Soft serif storybook captions. Uses absolute film frames. */
export const Captions: React.FC = () => {
  const frame = useCurrentFrame();
  const active = CAPTIONS.find((c) => frame >= c.from && frame < c.to);
  if (!active) return null;
  const fade = 24;
  const opacity = Math.min(
    interpolate(frame, [active.from, active.from + fade], [0, 1], { extrapolateRight: "clamp" }),
    interpolate(frame, [active.to - fade, active.to], [1, 0], { extrapolateLeft: "clamp" }),
  );
  const rise = interpolate(frame, [active.from, active.from + fade], [10, 0], { extrapolateRight: "clamp" });
  return (
    <AbsoluteFill style={{ justifyContent: "flex-end", alignItems: "center", paddingBottom: 70, pointerEvents: "none" }}>
      <div
        style={{
          opacity, transform: `translateY(${rise}px)`,
          fontFamily: "Georgia, 'Palatino Linotype', 'Book Antiqua', serif", fontStyle: "italic", fontSize: 50,
          letterSpacing: 0.4, color: active.color ?? "#fff6e0", textAlign: "center", maxWidth: 1400, lineHeight: 1.25,
          textShadow: "0 2px 14px rgba(40,24,8,0.55), 0 0 3px rgba(40,24,8,0.4)",
        }}
      >
        {active.text}
      </div>
    </AbsoluteFill>
  );
};
