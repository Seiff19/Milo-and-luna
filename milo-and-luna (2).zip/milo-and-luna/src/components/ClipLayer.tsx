import React from "react";
import { AbsoluteFill, interpolate, OffthreadVideo, Sequence, staticFile, useCurrentFrame } from "remotion";
import { FPS } from "../config";
import { shotsForAct, toPublicPath } from "../manifest";

/**
 * Overlays generated Higgsfield clips on top of the illustrated placeholder.
 * A shot is used only when assets-manifest.json marks it status "done"; missing shots
 * simply leave the placeholder visible (graceful fallback). Shots share the act's
 * duration equally; playbackRate stretches/squeezes each clip to fit its slot.
 */
export const ClipLayer: React.FC<{ actId: string; enabled: boolean }> = ({ actId, enabled }) => {
  return enabled ? <Inner actId={actId} /> : null;
};

const Inner: React.FC<{ actId: string }> = ({ actId }) => {
  const shots = shotsForAct(actId);
  const total = useActLength();
  if (shots.length === 0 || total === 0) return null;
  const slot = Math.round(total / shots.length);
  return (
    <AbsoluteFill>
      {shots.map((s, k) => {
        if (s.status !== "done") return null;
        const from = k * slot;
        const dur = k === shots.length - 1 ? total - from : slot;
        const rate = s.actualDurationSec ? Math.min(2, Math.max(0.5, (s.actualDurationSec * FPS) / dur)) : 1;
        return (
          <Sequence key={s.id} from={from} durationInFrames={dur} name={s.id}>
            <ShotVideo src={staticFile(toPublicPath(s.outputPath))} rate={rate} fadeIn={k > 0} />
          </Sequence>
        );
      })}
    </AbsoluteFill>
  );
};

const ShotVideo: React.FC<{ src: string; rate: number; fadeIn: boolean }> = ({ src, rate, fadeIn }) => {
  const frame = useCurrentFrame();
  const opacity = fadeIn ? interpolate(frame, [0, 10], [0, 1], { extrapolateRight: "clamp" }) : 1;
  return (
    <AbsoluteFill style={{ opacity }}>
      <OffthreadVideo src={src} muted playbackRate={rate} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
    </AbsoluteFill>
  );
};

// The act length is passed through context so ClipLayer needs no extra props.
export const ActLengthContext = React.createContext(0);
const useActLength = () => React.useContext(ActLengthContext);
