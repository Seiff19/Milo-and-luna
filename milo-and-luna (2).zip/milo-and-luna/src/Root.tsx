import React from "react";
import { Composition } from "remotion";
import { Film } from "./Film";
import { FPS, HEIGHT, TOTAL_FRAMES, WIDTH } from "./config";
import type { FilmProps } from "./types";

const defaultProps: FilmProps = {
  showCaptions: true,
  forcePlaceholders: false, // true = ignore generated clips and show the illustrated placeholders
  withAudio: true,
};

export const RemotionRoot: React.FC = () => (
  <Composition
    id="MiloAndLuna"
    component={Film}
    durationInFrames={TOTAL_FRAMES}
    fps={FPS}
    width={WIDTH}
    height={HEIGHT}
    defaultProps={defaultProps}
  />
);
