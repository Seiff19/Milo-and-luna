import React from "react";

export type RabbitWho = "milo" | "luna";

export type RabbitProps = {
  who: RabbitWho;
  x: number; // feet position
  y: number;
  scale?: number;
  pose?: "stand" | "sit";
  hopPhase?: number; // radians; presence = hopping
  hopHeight?: number;
  mood?: "happy" | "calm" | "sad";
  facing?: number; // -1..1 gaze/head direction
  lookDown?: number; // 0..1
  frame?: number; // drives ear sway + blinking
  wedding?: boolean;
  mature?: boolean;
  tilt?: number;
  opacity?: number;
  garment?: { kind: "vest" | "cardigan" | "suit" | "dress" | "shirt"; color: string };
};

// Canonical look (keep in sync with assets-manifest.json descriptors):
// Both: warm honey-tan fur, cream belly (matches reference/storyboard.jpg).
// Milo = slightly deeper tan + light-blue scarf. Luna = slightly lighter/creamier + pink ribbon on LEFT ear.
const P = {
  milo: { fur: "#cf9c63", dark: "#9c6a38", belly: "#f7e6c8", inner: "#f0b79c", accent: "#7fb0d8", accent2: "#5f93c0" },
  luna: { fur: "#dcb283", dark: "#a9794a", belly: "#f8ecd6", inner: "#f4c2cb", accent: "#f08aa8", accent2: "#d96f90" },
};

export const Rabbit: React.FC<RabbitProps> = ({
  who, x, y, scale = 1, pose = "stand", hopPhase, hopHeight = 60, mood = "happy",
  facing = 0, lookDown = 0, frame = 0, wedding = false, mature = false, tilt = 0, opacity = 1, garment,
}) => {
  const c = P[who];
  const hopping = hopPhase !== undefined;
  const s = hopping ? Math.abs(Math.sin(hopPhase as number)) : 0;
  const lift = s * hopHeight;
  const squash = hopping ? 1 - 0.08 * (1 - s) : 1;
  const sit = pose === "sit";
  const bodyCy = sit ? -42 : -55;
  const bodyRy = sit ? 40 : 48;
  const bodyRx = sit ? 46 : 42;
  const headY = sit ? -104 : -118;
  const sway = Math.sin(frame / 22 + (who === "luna" ? 1 : 0)) * 3;
  const spread = mood === "sad" ? 46 : mood === "calm" ? 14 : 9;
  const earLen = mood === "sad" ? 34 : 42;
  const blinkT = (frame + (who === "luna" ? 47 : 0)) % 150;
  const eyeY = blinkT < 5 ? 0.1 : mood === "sad" ? 0.5 : 1;
  const fx = facing * 7;
  const fy = lookDown * 5;
  const ear = (side: -1 | 1) => (
    <g transform={`translate(${side * 20} ${headY - 24}) rotate(${side * spread + sway * side})`}>
      <ellipse cx={0} cy={-earLen * 0.9} rx={13} ry={earLen} fill={c.fur} stroke={c.dark} strokeWidth={2} strokeOpacity={0.5} />
      <ellipse cx={0} cy={-earLen * 0.85} rx={6.5} ry={earLen * 0.72} fill={c.inner} opacity={0.9} />
    </g>
  );

  return (
    <g transform={`translate(${x} ${y}) scale(${scale})`} opacity={opacity}>
      <ellipse cx={0} cy={4} rx={60 - lift * 0.3} ry={9} fill="#3a2a1a" opacity={Math.max(0.06, 0.2 - lift * 0.002)} />
      <g transform={`translate(0 ${-lift}) scale(1 ${squash}) rotate(${tilt})`} filter="url(#wc-edge)">
        {/* tail + feet */}
        <circle cx={-44} cy={-34} r={15} fill="#fffaf0" stroke={c.dark} strokeOpacity={0.3} strokeWidth={2} />
        <ellipse cx={-26} cy={-8} rx={27} ry={11} fill={c.fur} stroke={c.dark} strokeOpacity={0.5} strokeWidth={2} />
        <ellipse cx={26} cy={-8} rx={27} ry={11} fill={c.fur} stroke={c.dark} strokeOpacity={0.5} strokeWidth={2} />
        {/* body */}
        <ellipse cx={0} cy={bodyCy} rx={bodyRx} ry={bodyRy} fill={c.fur} stroke={c.dark} strokeWidth={2} strokeOpacity={0.5} />
        <ellipse cx={4} cy={bodyCy + 4} rx={bodyRx * 0.62} ry={bodyRy * 0.72} fill={c.belly} opacity={0.95} />
        {garment && garment.kind !== "dress" && (
          <g>
            <ellipse cx={0} cy={bodyCy + 8} rx={bodyRx * 0.98} ry={bodyRy * 0.78} fill={garment.color} opacity={0.96} />
            <path d={`M-9 ${bodyCy - bodyRy * 0.55} L0 ${bodyCy + bodyRy * 0.7} L9 ${bodyCy - bodyRy * 0.55} Z`} fill={c.belly} />
            {garment.kind === "suit" && <path d={`M-9 ${bodyCy - bodyRy * 0.55} L-22 ${bodyCy - bodyRy * 0.2} L-6 ${bodyCy + 4} Z M9 ${bodyCy - bodyRy * 0.55} L22 ${bodyCy - bodyRy * 0.2} L6 ${bodyCy + 4} Z`} fill="#5d6068" />}
          </g>
        )}
        {garment?.kind === "dress" && (
          <path d={`M-20 ${headY + 30} Q-74 -40 -96 -2 L96 -2 Q74 -40 20 ${headY + 30} Z`} fill="#fffdf8" stroke="#e8dcc8" strokeWidth={2} />
        )}
        <ellipse cx={-14} cy={-14} rx={10} ry={8} fill={c.belly} />
        <ellipse cx={14} cy={-14} rx={10} ry={8} fill={c.belly} />
        {/* ears behind head */}
        {ear(-1)}
        {ear(1)}
        {/* head */}
        <g transform={`rotate(${facing * 4} 0 ${headY})`}>
          <ellipse cx={fx * 0.6} cy={headY} rx={40} ry={35} fill={c.fur} stroke={c.dark} strokeWidth={2} strokeOpacity={0.5} />
          {mature && <ellipse cx={fx} cy={headY + 12} rx={20} ry={13} fill="#ffffff" opacity={0.28} />}
          <g transform={`translate(${fx} ${fy})`}>
            <circle cx={-26} cy={headY + 10} r={8} fill="#f08f8f" opacity={0.3} />
            <circle cx={26} cy={headY + 10} r={8} fill="#f08f8f" opacity={0.3} />
            <ellipse cx={-15} cy={headY - 2} rx={5.2} ry={6.2 * eyeY} fill="#2b1d14" />
            <ellipse cx={15} cy={headY - 2} rx={5.2} ry={6.2 * eyeY} fill="#2b1d14" />
            {eyeY > 0.4 && <circle cx={-13.4} cy={headY - 4.5} r={1.8} fill="#fff" />}
            {eyeY > 0.4 && <circle cx={16.6} cy={headY - 4.5} r={1.8} fill="#fff" />}
            {who === "luna" && (
              <path d={`M-22 ${headY - 6} l-5 -4 M22 ${headY - 6} l5 -4`} stroke="#2b1d14" strokeWidth={2} strokeLinecap="round" />
            )}
            {mature && <path d={`M-24 ${headY - 14} q9 -5 17 -1 M24 ${headY - 14} q-9 -5 -17 -1`} stroke="#fff" strokeOpacity={0.5} strokeWidth={2} fill="none" strokeLinecap="round" />}
            <ellipse cx={0} cy={headY + 10} rx={5} ry={3.6} fill="#d9707a" />
            {mood === "sad" ? (
              <path d={`M-8 ${headY + 21} q8 -6 16 0`} stroke="#6b4a3a" strokeWidth={2} fill="none" strokeLinecap="round" />
            ) : (
              <path d={`M0 ${headY + 14} q-6 7 -12 3 M0 ${headY + 14} q6 7 12 3`} stroke="#6b4a3a" strokeWidth={2} fill="none" strokeLinecap="round" />
            )}
            <path d={`M-30 ${headY + 9} l-22 -4 M-30 ${headY + 13} l-22 3 M30 ${headY + 9} l22 -4 M30 ${headY + 13} l22 3`} stroke="#6b4a3a" strokeOpacity={0.35} strokeWidth={1.4} />
          </g>
          {/* Luna: coral ribbon on LEFT ear */}
          {who === "luna" && (
            <g transform={`translate(-24 ${headY - 28})`}>
              <ellipse cx={-8} cy={0} rx={10} ry={5} fill={c.accent} transform="rotate(-25)" />
              <ellipse cx={8} cy={0} rx={10} ry={5} fill={c.accent} transform="rotate(25)" />
              <circle cx={0} cy={0} r={4.5} fill={c.accent2} />
            </g>
          )}
          {/* Luna wedding: veil + flower crown */}
          {who === "luna" && wedding && (
            <g>
              <path d={`M-48 ${headY - 6} Q0 ${headY - 52} 48 ${headY - 6} L66 -6 L-66 -6 Z`} fill="#ffffff" opacity={0.3} />
              {[-30, -15, 0, 15, 30].map((px, i) => (
                <circle key={i} cx={px} cy={headY - 30 + Math.abs(px) * 0.25} r={5} fill={i % 2 ? "#ffe3ea" : "#fff"} stroke="#f2a7b8" strokeWidth={1.2} />
              ))}
            </g>
          )}
        </g>
        {/* Milo: teal scarf */}
        {who === "milo" && garment?.kind !== "suit" && (
          <g>
            <ellipse cx={0} cy={headY + 32} rx={32} ry={10} fill={c.accent} stroke={c.accent2} strokeWidth={1.5} />
            <path d={`M12 ${headY + 36} l10 34 l14 -4 l-6 -32 z`} fill={c.accent2} />
          </g>
        )}
        {who === "milo" && wedding && <circle cx={-16} cy={headY + 44} r={6} fill="#fffdf6" stroke="#f2a7b8" strokeWidth={1.5} />}
      </g>
    </g>
  );
};
