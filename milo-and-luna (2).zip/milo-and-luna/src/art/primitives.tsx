import React from "react";
import { random } from "remotion";

export const W = 1920;
export const H = 1080;

/** Shared SVG filters. Same ids everywhere so duplicates during crossfades are harmless. */
export const WatercolorDefs: React.FC = () => (
  <defs>
    <filter id="wc-edge" x="-8%" y="-8%" width="116%" height="116%">
      <feTurbulence type="fractalNoise" baseFrequency="0.03" numOctaves={3} seed={4} result="n" />
      <feDisplacementMap in="SourceGraphic" in2="n" scale={5} xChannelSelector="R" yChannelSelector="G" />
    </filter>
    <filter id="wc-wash" x="-5%" y="-5%" width="110%" height="110%">
      <feTurbulence type="fractalNoise" baseFrequency="0.006" numOctaves={4} seed={9} result="n" />
      <feDisplacementMap in="SourceGraphic" in2="n" scale={36} xChannelSelector="R" yChannelSelector="G" />
      <feGaussianBlur stdDeviation={1.2} />
    </filter>
    <filter id="wc-blur" x="-50%" y="-50%" width="200%" height="200%">
      <feGaussianBlur stdDeviation={24} />
    </filter>
    <filter id="wc-glow" x="-50%" y="-50%" width="200%" height="200%">
      <feGaussianBlur stdDeviation={8} />
    </filter>
    <filter id="wc-paper" x="0" y="0" width="100%" height="100%">
      <feTurbulence type="fractalNoise" baseFrequency={0.85} numOctaves={3} seed={2} result="n" />
      <feColorMatrix in="n" type="matrix" values="0 0 0 0 0.42  0 0 0 0 0.33  0 0 0 0 0.24  0.9 0 0 0 -0.32" />
    </filter>
    <radialGradient id="wc-vignette" cx="50%" cy="50%" r="75%">
      <stop offset="60%" stopColor="#3a2410" stopOpacity={0} />
      <stop offset="100%" stopColor="#3a2410" stopOpacity={0.28} />
    </radialGradient>
  </defs>
);

/** Paper grain + vignette overlay. Put last in the SVG. */
export const PaperOverlay: React.FC<{ grain?: number }> = ({ grain = 0.45 }) => (
  <g pointerEvents="none">
    <rect width={W} height={H} filter="url(#wc-paper)" opacity={grain} style={{ mixBlendMode: "multiply" }} />
    <rect width={W} height={H} fill="url(#wc-vignette)" />
  </g>
);

export const SceneSVG: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <svg viewBox={`0 0 ${W} ${H}`} width={W} height={H} style={{ position: "absolute", inset: 0 }}>
    <WatercolorDefs />
    {children}
  </svg>
);

export const Sky: React.FC<{ id: string; stops: [string, string, string] }> = ({ id, stops }) => (
  <g>
    <defs>
      <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor={stops[0]} />
        <stop offset="55%" stopColor={stops[1]} />
        <stop offset="100%" stopColor={stops[2]} />
      </linearGradient>
    </defs>
    <rect width={W} height={H} fill={`url(#${id})`} />
  </g>
);

export const Sun: React.FC<{ id: string; x: number; y: number; r: number; color?: string; glow?: string; pulse?: number }> = ({
  id, x, y, r, color = "#fff2c4", glow = "#ffd27a", pulse = 0,
}) => (
  <g>
    <defs>
      <radialGradient id={id}>
        <stop offset="0%" stopColor={glow} stopOpacity={0.9} />
        <stop offset="100%" stopColor={glow} stopOpacity={0} />
      </radialGradient>
    </defs>
    <circle cx={x} cy={y} r={r * (3.2 + pulse * 0.2)} fill={`url(#${id})`} />
    <circle cx={x} cy={y} r={r} fill={color} filter="url(#wc-edge)" />
  </g>
);

export const Cloud: React.FC<{ x: number; y: number; s?: number; color?: string; opacity?: number }> = ({ x, y, s = 1, color = "#ffffff", opacity = 0.6 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} opacity={opacity} filter="url(#wc-wash)">
    <ellipse cx={0} cy={0} rx={130} ry={34} fill={color} />
    <ellipse cx={-60} cy={-22} rx={70} ry={34} fill={color} />
    <ellipse cx={40} cy={-30} rx={80} ry={40} fill={color} />
  </g>
);

export const Hill: React.FC<{ y: number; amp: number; color: string; seed: number; opacity?: number; wash?: boolean }> = ({ y, amp, color, seed, opacity = 1, wash = true }) => {
  let d = `M-120 ${H + 40}`;
  for (let x = -120; x <= W + 120; x += 40) {
    const yy = y + amp * Math.sin(x / 310 + seed) + amp * 0.5 * Math.sin(x / 133 + seed * 2.1);
    d += ` L${x} ${yy.toFixed(1)}`;
  }
  d += ` L${W + 120} ${H + 40} Z`;
  return <path d={d} fill={color} opacity={opacity} filter={wash ? "url(#wc-wash)" : undefined} />;
};

/** Many grass blades in one path; swayed as a group. */
export const GrassBlades: React.FC<{ frame: number; count: number; yMin: number; yMax: number; colors: string[]; seed: string; height?: number }> = ({
  frame, count, yMin, yMax, colors, seed, height = 60,
}) => {
  const groups = colors.map((_, ci) => {
    let d = "";
    for (let i = ci; i < count; i += colors.length) {
      const x = random(`${seed}x${i}`) * (W + 80) - 40;
      const y = yMin + random(`${seed}y${i}`) * (yMax - yMin);
      const h = height * (0.6 + random(`${seed}h${i}`) * 0.8);
      const bend = (random(`${seed}b${i}`) - 0.5) * 24;
      d += `M${x.toFixed(0)} ${y.toFixed(0)} q${(bend * 0.5).toFixed(0)} ${(-h / 2).toFixed(0)} ${bend.toFixed(0)} ${(-h).toFixed(0)} `;
    }
    return d;
  });
  const skew = Math.sin(frame / 40) * 1.6;
  return (
    <g transform={`skewX(${skew})`} style={{ transformOrigin: `0px ${yMax}px` }}>
      {groups.map((d, i) => (
        <path key={i} d={d} stroke={colors[i]} strokeWidth={3.2} strokeLinecap="round" fill="none" opacity={0.85} />
      ))}
    </g>
  );
};

export const Dandelion: React.FC<{ x: number; y: number; h: number; puff: boolean; frame: number; i: number }> = ({ x, y, h, puff, frame, i }) => {
  const sway = Math.sin(frame / 35 + i) * 4;
  const hx = x + sway, hy = y - h;
  return (
    <g>
      <path d={`M${x} ${y} Q${x + sway * 0.4} ${y - h / 2} ${hx} ${hy}`} stroke="#6f9a4a" strokeWidth={4} fill="none" strokeLinecap="round" />
      {puff ? (
        <g filter="url(#wc-edge)">
          <circle cx={hx} cy={hy} r={20} fill="#fffdf4" opacity={0.85} />
          {Array.from({ length: 12 }, (_, k) => {
            const a = (k / 12) * Math.PI * 2;
            return <line key={k} x1={hx} y1={hy} x2={hx + Math.cos(a) * 24} y2={hy + Math.sin(a) * 24} stroke="#d9d4c0" strokeWidth={1.2} />;
          })}
        </g>
      ) : (
        <circle cx={hx} cy={hy} r={12} fill="#f7c93c" filter="url(#wc-edge)" />
      )}
    </g>
  );
};

export const Wildflower: React.FC<{ x: number; y: number; h: number; color: string; frame: number; i: number; r?: number }> = ({ x, y, h, color, frame, i, r = 11 }) => {
  const sway = Math.sin(frame / 38 + i * 1.7) * 3;
  const hx = x + sway, hy = y - h;
  return (
    <g>
      <path d={`M${x} ${y} Q${x + sway * 0.3} ${y - h / 2} ${hx} ${hy}`} stroke="#6f9a4a" strokeWidth={3} fill="none" strokeLinecap="round" />
      <g filter="url(#wc-edge)">
        {[0, 72, 144, 216, 288].map((a) => (
          <circle key={a} cx={hx + Math.cos((a * Math.PI) / 180) * r} cy={hy + Math.sin((a * Math.PI) / 180) * r} r={r * 0.85} fill={color} opacity={0.9} />
        ))}
        <circle cx={hx} cy={hy} r={r * 0.5} fill="#ffe28a" />
      </g>
    </g>
  );
};

export const Butterfly: React.FC<{ x: number; y: number; frame: number; color: string; s?: number }> = ({ x, y, frame, color, s = 1 }) => {
  const flap = 0.35 + 0.65 * Math.abs(Math.cos(frame * 0.35));
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      <g transform={`scale(${flap} 1)`}>
        <ellipse cx={-14} cy={-6} rx={14} ry={11} fill={color} opacity={0.9} />
        <ellipse cx={14} cy={-6} rx={14} ry={11} fill={color} opacity={0.9} />
        <ellipse cx={-10} cy={8} rx={9} ry={7} fill={color} opacity={0.7} />
        <ellipse cx={10} cy={8} rx={9} ry={7} fill={color} opacity={0.7} />
      </g>
      <rect x={-1.5} y={-10} width={3} height={22} rx={1.5} fill="#4a3426" />
    </g>
  );
};

/** Drifting petals / seeds / motes. */
export const Drifters: React.FC<{ frame: number; count: number; colors: string[]; seed: string; speed?: number; size?: number; rise?: boolean; wind?: number }> = ({
  frame, count, colors, seed, speed = 1, size = 7, rise = false, wind = 0.6,
}) => (
  <g>
    {Array.from({ length: count }, (_, i) => {
      const bx = random(`${seed}x${i}`) * W;
      const by = random(`${seed}y${i}`) * (H + 100);
      const v = (0.5 + random(`${seed}v${i}`)) * speed;
      const dir = rise ? -1 : 1;
      const y = (((by + dir * frame * v * 1.2) % (H + 100)) + (H + 100)) % (H + 100) - 50;
      const x = ((bx + frame * wind * v + Math.sin(frame / 30 + i) * 30) % (W + 100) + (W + 100)) % (W + 100) - 50;
      const rot = frame * 2 * v + i * 40;
      return (
        <ellipse key={i} cx={x} cy={y} rx={size * (0.7 + random(`${seed}s${i}`) * 0.6)} ry={size * 0.5} fill={colors[i % colors.length]} opacity={0.75} transform={`rotate(${rot} ${x} ${y})`} />
      );
    })}
  </g>
);

export const LightRays: React.FC<{ frame: number; color?: string; opacity?: number; originX?: number }> = ({ frame, color = "#fff3c9", opacity = 0.16, originX = 1500 }) => (
  <g style={{ mixBlendMode: "screen" }} pointerEvents="none">
    {[0, 1, 2, 3, 4].map((i) => {
      const spread = 220 + i * 160;
      const o = opacity * (0.7 + 0.3 * Math.sin(frame / 50 + i));
      return <polygon key={i} points={`${originX - 20 + i * 8},-40 ${originX + 40 + i * 8},-40 ${originX - spread - 300},${H} ${originX - spread - 120},${H}`} fill={color} opacity={o} filter="url(#wc-glow)" />;
    })}
  </g>
);

export const FairyLights: React.FC<{ frame: number; path: string; points: [number, number][]; color?: string }> = ({ frame, path, points, color = "#ffd98a" }) => (
  <g>
    <path d={path} stroke="#6a4a2c" strokeWidth={2.5} fill="none" opacity={0.7} />
    {points.map(([px, py], i) => {
      const tw = 0.65 + 0.35 * Math.sin(frame / 12 + i * 1.9);
      return (
        <g key={i}>
          <circle cx={px} cy={py} r={20} fill={color} opacity={0.35 * tw} filter="url(#wc-glow)" />
          <circle cx={px} cy={py} r={5.5} fill="#fff4cf" opacity={0.7 + 0.3 * tw} />
        </g>
      );
    })}
  </g>
);

/** Quadratic-sagging string helper: returns svg path and bulb positions between two points. */
export const sagString = (x1: number, y1: number, x2: number, y2: number, sag: number, bulbs: number) => {
  const cx = (x1 + x2) / 2, cy = Math.max(y1, y2) + sag;
  const path = `M${x1} ${y1} Q${cx} ${cy} ${x2} ${y2}`;
  const pts: [number, number][] = Array.from({ length: bulbs }, (_, i) => {
    const t = (i + 1) / (bulbs + 1);
    return [(1 - t) * (1 - t) * x1 + 2 * (1 - t) * t * cx + t * t * x2, (1 - t) * (1 - t) * y1 + 2 * (1 - t) * t * cy + t * t * y2] as [number, number];
  });
  return { path, pts };
};

export const ScatterFlowers: React.FC<{ frame: number; count: number; yMin: number; yMax: number; seed: string; colors: string[]; dandelions?: boolean }> = ({
  frame, count, yMin, yMax, seed, colors, dandelions = true,
}) => {
  const items = Array.from({ length: count }, (_, i) => ({
    i, x: 30 + random(`${seed}x${i}`) * (W - 60), y: yMin + random(`${seed}y${i}`) * (yMax - yMin), h: 45 + random(`${seed}h${i}`) * 55,
  })).sort((a, b) => a.y - b.y);
  return (
    <g>
      {items.map((f) => {
        const depth = (f.y - yMin) / (yMax - yMin);
        const sc = 0.65 + depth * 0.6;
        return (
          <g key={f.i} transform={`translate(${f.x} ${f.y}) scale(${sc}) translate(${-f.x} ${-f.y})`}>
            {dandelions && f.i % 3 === 0 ? (
              <Dandelion x={f.x} y={f.y} h={f.h} puff={f.i % 2 === 0} frame={frame} i={f.i} />
            ) : (
              <Wildflower x={f.x} y={f.y} h={f.h} color={colors[f.i % colors.length]} frame={frame} i={f.i} />
            )}
          </g>
        );
      })}
    </g>
  );
};
