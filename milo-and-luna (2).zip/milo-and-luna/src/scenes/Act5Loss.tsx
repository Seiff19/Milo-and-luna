import React from "react";
import { useCurrentFrame } from "remotion";
import { Rabbit } from "../art/Rabbit";
import { Drifters, PaperOverlay, SceneSVG } from "../art/primitives";

/** Act 5 - Sudden Loss: cool, muted, nearly still. Luna, one candle, an empty chair. */
export const Act5Loss: React.FC = () => {
  const frame = useCurrentFrame();
  const flick = 0.5 + 0.5 * Math.sin(frame / 7) * Math.sin(frame / 11 + 1);
  const flameH = 20 + flick * 7;
  const glow = 0.3 + flick * 0.1;
  const breathe = Math.sin(frame / 70) * 0.8;
  return (
    <SceneSVG>
      <defs>
        <linearGradient id="a5-wall" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#2b3447" /><stop offset="1" stopColor="#3b4863" /></linearGradient>
        <radialGradient id="a5-candle"><stop offset="0" stopColor="#ffcf8a" stopOpacity={0.85} /><stop offset="1" stopColor="#ffcf8a" stopOpacity={0} /></radialGradient>
        <filter id="a5-desat"><feColorMatrix type="saturate" values="0.55" /></filter>
      </defs>
      <g filter="url(#a5-desat)">
        <rect width={1920} height={1080} fill="url(#a5-wall)" />
        <rect y={850} width={1920} height={230} fill="#1f2634" filter="url(#wc-wash)" />
        {/* window with moon */}
        <g filter="url(#wc-edge)">
          <circle cx={1500} cy={360} r={170} fill="#46557a" stroke="#2a3248" strokeWidth={16} />
          <circle cx={1540} cy={320} r={34} fill="#cfd9ec" opacity={0.9} />
          <circle cx={1556} cy={308} r={30} fill="#46557a" />
          <path d="M1500 190 V530 M1330 360 H1670" stroke="#2a3248" strokeWidth={8} />
        </g>
        <polygon points="1330,540 1670,540 1500,1000 1100,1000" fill="#9fb4de" opacity={0.08} style={{ mixBlendMode: "screen" }} />
        {/* small table + candle */}
        <g filter="url(#wc-edge)">
          <rect x={430} y={700} width={240} height={18} rx={4} fill="#4a4a58" />
          <rect x={450} y={718} width={16} height={170} fill="#3d3d4b" />
          <rect x={634} y={718} width={16} height={170} fill="#3d3d4b" />
          <rect x={532} y={650} width={36} height={50} rx={6} fill="#e9e1d0" />
        </g>
        <circle cx={550} cy={640} r={300} fill="url(#a5-candle)" opacity={glow * 1.6} style={{ mixBlendMode: "screen" }} />
        <ellipse cx={550 + Math.sin(frame / 9) * 1.5} cy={632} rx={9} ry={flameH * 0.7} fill="#ffb55a" />
        <ellipse cx={550} cy={636} rx={5} ry={flameH * 0.4} fill="#fff1c4" />
        {/* empty chair + teal scarf */}
        <g filter="url(#wc-edge)">
          <rect x={1010} y={640} width={20} height={250} fill="#6b5240" />
          <rect x={1180} y={640} width={20} height={250} fill="#6b5240" />
          <rect x={1010} y={640} width={190} height={22} rx={6} fill="#7a5f4a" />
          <rect x={1000} y={780} width={210} height={26} rx={6} fill="#7a5f4a" />
          <rect x={1010} y={806} width={16} height={88} fill="#5c4636" />
          <rect x={1184} y={806} width={16} height={88} fill="#5c4636" />
          <path d="M1040 650 C1030 720 1050 760 1060 830 L1096 826 C1086 760 1076 710 1086 650 Z" fill="#7fb0d8" />
          <ellipse cx={1054} cy={836} rx={30} ry={9} fill="#5f93c0" />
        </g>
        <ellipse cx={1105} cy={900} rx={160} ry={16} fill="#000" opacity={0.18} />
        <Rabbit who="luna" garment={{ kind: "cardigan", color: "#f4a6b8" }} x={800} y={930} scale={1.05} pose="sit" mature mood="sad" facing={0.8} lookDown={0.8} tilt={3 + breathe} frame={frame} />
        <Drifters frame={frame} count={30} seed="a5m" colors={["#cfd9ec"]} size={3} speed={0.12} rise wind={0.1} />
      </g>
      <rect width={1920} height={1080} fill="#1c2a4a" opacity={0.28} style={{ mixBlendMode: "multiply" }} />
      <PaperOverlay grain={0.35} />
    </SceneSVG>
  );
};
