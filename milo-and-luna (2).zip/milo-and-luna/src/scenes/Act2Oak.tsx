import React from "react";
import { interpolate, random, useCurrentFrame } from "remotion";
import { Rabbit } from "../art/Rabbit";
import { Cloud, Drifters, GrassBlades, Hill, LightRays, PaperOverlay, ScatterFlowers, SceneSVG, Sky, Sun } from "../art/primitives";

const Book: React.FC<{ cx: number; cy: number; frame: number }> = ({ cx, cy, frame }) => {
  const cyc = frame % 180;
  const flip = cyc < 24 ? Math.cos((cyc / 24) * Math.PI) : cyc > 150 ? 1 : -1; // quick page turn
  return (
    <g filter="url(#wc-edge)">
      <polygon points={`${cx - 86},${cy - 28} ${cx},${cy - 42} ${cx},${cy + 8} ${cx - 86},${cy + 22}`} fill="#fffaf0" stroke="#b79a76" strokeWidth={2} />
      <polygon points={`${cx + 86},${cy - 28} ${cx},${cy - 42} ${cx},${cy + 8} ${cx + 86},${cy + 22}`} fill="#fff6e6" stroke="#b79a76" strokeWidth={2} />
      {[0, 1, 2, 3].map((i) => (
        <g key={i} stroke="#a38b6a" strokeOpacity={0.55} strokeWidth={2}>
          <line x1={cx - 74} y1={cy - 20 + i * 8} x2={cx - 14} y2={cy - 27 + i * 8} />
          <line x1={cx + 14} y1={cy - 27 + i * 8} x2={cx + 74} y2={cy - 20 + i * 8} />
        </g>
      ))}
      <g transform={`translate(${cx} 0) scale(${flip} 1) translate(${-cx} 0)`}>
        <polygon points={`${cx},${cy - 42} ${cx + 86},${cy - 28} ${cx + 86},${cy + 22} ${cx},${cy + 8}`} fill="#fffdf7" stroke="#b79a76" strokeWidth={2} opacity={cyc < 24 ? 0.95 : 0} />
      </g>
      <path d={`M${cx - 92} ${cy + 24} L${cx} ${cy + 12} L${cx + 92} ${cy + 24}`} stroke="#7a3f3f" strokeWidth={7} fill="none" strokeLinecap="round" />
    </g>
  );
};

/** Act 2 - Learning & Growing: reading side by side under a blossoming oak. */
export const Act2Oak: React.FC = () => {
  const frame = useCurrentFrame();
  const canopy = Array.from({ length: 16 }, (_, i) => ({
    x: 1380 + (random(`a2cx${i}`) - 0.5) * 560, y: 320 + (random(`a2cy${i}`) - 0.5) * 260,
    r: 120 + random(`a2cr${i}`) * 90, c: ["#8fbf6a", "#7fb25c", "#a3cb78"][i % 3],
  }));
  const blossoms = Array.from({ length: 90 }, (_, i) => ({
    x: 1380 + (random(`a2bx${i}`) - 0.5) * 640, y: 320 + (random(`a2by${i}`) - 0.5) * 330,
    r: 6 + random(`a2br${i}`) * 8, c: ["#f7c1d0", "#fff", "#f4a9bf"][i % 3],
  }));
  const bob = Math.sin(frame / 60) * 1.2;

  return (
    <SceneSVG>
      <Sky id="a2-sky" stops={["#f6cf94", "#fde7c2", "#fff1d9"]} />
      <Sun id="a2-sun" x={420} y={250} r={70} glow="#ffcf80" />
      <Cloud x={((frame * 0.15 + 300) % 2300) - 200} y={170} s={1} opacity={0.5} />
      <Hill y={600} amp={40} color="#cfe0b4" seed={3} opacity={0.9} />
      <Hill y={700} amp={44} color="#a9cf86" seed={5} />
      <rect y={790} width={1920} height={300} fill="#8cc067" filter="url(#wc-wash)" />
      <GrassBlades frame={frame} count={220} yMin={800} yMax={1040} colors={["#6fa24b", "#8cc063", "#5d9140"]} seed="a2g" />
      {/* oak */}
      <g>
        <path d="M1325 890 C1340 720 1360 560 1335 420 L1425 420 C1410 560 1435 720 1460 890 Z" fill="#8a5f3a" stroke="#5e3f24" strokeWidth={3} filter="url(#wc-edge)" />
        <path d="M1360 830 C1368 700 1372 600 1362 480 M1400 840 C1396 720 1404 620 1396 500" stroke="#5e3f24" strokeOpacity={0.4} strokeWidth={4} fill="none" />
        <g filter="url(#wc-wash)">{canopy.map((c, i) => <circle key={i} cx={c.x} cy={c.y} r={c.r} fill={c.c} opacity={0.92} />)}</g>
        <g filter="url(#wc-edge)">{blossoms.map((b, i) => <circle key={i} cx={b.x} cy={b.y} r={b.r} fill={b.c} opacity={0.85} />)}</g>
      </g>
      <ScatterFlowers frame={frame} count={26} yMin={820} yMax={960} seed="a2f" colors={["#f48fb1", "#fff4c2", "#b39ddb"]} />
      <Rabbit who="milo" garment={{ kind: "vest", color: "#6f9ec9" }} x={905} y={915} scale={0.85} pose="sit" facing={0.7} lookDown={1} tilt={bob} frame={frame} mood="calm" />
      <Rabbit who="luna" garment={{ kind: "cardigan", color: "#f4a6b8" }} x={1085} y={915} scale={0.85} pose="sit" facing={-0.7} lookDown={1} tilt={-bob} frame={frame} mood="calm" />
      <Book cx={995} cy={925} frame={frame} />
      <Drifters frame={frame} count={34} seed="a2p" colors={["#f7c1d0", "#ffffff", "#f4a9bf"]} size={8} speed={0.45} wind={0.35} />
      <LightRays frame={frame} originX={interpolate(frame, [0, 780], [1300, 1100], { extrapolateRight: "clamp" })} opacity={0.14} />
      <PaperOverlay />
    </SceneSVG>
  );
};
