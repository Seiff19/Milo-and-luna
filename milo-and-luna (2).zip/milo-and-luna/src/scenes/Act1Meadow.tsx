import React from "react";
import { useCurrentFrame } from "remotion";
import { Rabbit } from "../art/Rabbit";
import { Butterfly, Cloud, Drifters, GrassBlades, Hill, LightRays, PaperOverlay, ScatterFlowers, SceneSVG, Sky, Sun } from "../art/primitives";

const FLOWER_COLORS = ["#f48fb1", "#fff4c2", "#b39ddb", "#ffab91", "#90caf9"];

/** Act 1 - Childhood Friendship: two young rabbits hopping in a sunlit meadow. */
export const Act1Meadow: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / 30;
  const mx = 780 + 340 * Math.sin(t * 0.55);
  const lx = 780 + 340 * Math.sin(t * 0.55 - 0.9);
  const dir = Math.cos(t * 0.55) > 0 ? 1 : -1;
  const hop = frame * 0.14;

  return (
    <SceneSVG>
      <Sky id="a1-sky" stops={["#fbd29a", "#fff0cf", "#fde9b8"]} />
      <Sun id="a1-sun" x={1480} y={210} r={86} pulse={Math.sin(frame / 40)} />
      <Cloud x={(frame * 0.25) % 2300 - 200} y={190} s={1.2} />
      <Cloud x={((frame * 0.18 + 900) % 2300) - 200} y={300} s={0.8} opacity={0.45} />
      <Hill y={560} amp={34} color="#cfe0b4" seed={1} opacity={0.9} />
      <Hill y={650} amp={46} color="#b4d494" seed={2.4} />
      <Hill y={745} amp={30} color="#93c471" seed={4} />
      <rect y={800} width={1920} height={300} fill="#86bb62" opacity={0.9} filter="url(#wc-wash)" />
      <GrassBlades frame={frame} count={260} yMin={790} yMax={1040} colors={["#6fa24b", "#8cc063", "#5d9140"]} seed="a1g" />
      <ScatterFlowers frame={frame} count={46} yMin={800} yMax={940} seed="a1fb" colors={FLOWER_COLORS} />
      <Butterfly x={420 + 520 * Math.sin(frame / 90)} y={430 + 60 * Math.sin(frame / 23)} frame={frame} color="#ffb74d" />
      <Butterfly x={1300 + 300 * Math.sin(frame / 70 + 2)} y={520 + 50 * Math.sin(frame / 31)} frame={frame + 7} color="#f48fb1" s={0.8} />
      <Rabbit who="luna" x={lx} y={958} scale={0.5} hopPhase={hop - 0.8} hopHeight={46} facing={dir} frame={frame} />
      <Rabbit who="milo" x={mx} y={930} scale={0.52} hopPhase={hop} hopHeight={50} facing={dir} frame={frame} />
      <ScatterFlowers frame={frame} count={28} yMin={975} yMax={1060} seed="a1ff" colors={FLOWER_COLORS} />
      <Drifters frame={frame} count={26} seed="a1seed" colors={["#fffdf4"]} size={5} speed={0.5} rise wind={0.7} />
      <LightRays frame={frame} />
      <PaperOverlay />
    </SceneSVG>
  );
};
