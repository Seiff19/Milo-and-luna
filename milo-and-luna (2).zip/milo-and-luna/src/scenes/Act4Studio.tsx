import React from "react";
import { interpolate, random, useCurrentFrame } from "remotion";
import { Rabbit } from "../art/Rabbit";
import { PaperOverlay, SceneSVG } from "../art/primitives";

const clamp = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;
const reveal = (f: number, start: number, dur: number) => interpolate(f, [start, start + dur], [0, 1], clamp);

const Sparkle: React.FC<{ x: number; y: number; frame: number; i: number }> = ({ x, y, frame, i }) => {
  const p = ((frame + i * 37) % 120) / 120;
  const s = Math.sin(p * Math.PI);
  return (
    <path
      d={`M${x} ${y - 16 * s} Q${x} ${y} ${x + 16 * s} ${y} Q${x} ${y} ${x} ${y + 16 * s} Q${x} ${y} ${x - 16 * s} ${y} Q${x} ${y} ${x} ${y - 16 * s} Z`}
      fill="#fff2b0" opacity={0.9 * s} transform={`translate(0 ${-p * 40})`}
    />
  );
};

/** Act 4 - Mutual Growth: two mature rabbits painting one shared canvas. */
export const Act4Studio: React.FC = () => {
  const frame = useCurrentFrame();
  const cL = 640, cR = 1280, cT = 190, cB = 700;
  const mTip = { x: 700 + 90 * Math.sin(frame / 18), y: 470 + 60 * Math.cos(frame / 23) };
  const lTip = { x: 1220 - 90 * Math.sin(frame / 20 + 1), y: 470 + 60 * Math.cos(frame / 25 + 2) };
  const lamp = 0.8 + 0.2 * Math.sin(frame / 25);
  return (
    <SceneSVG>
      <defs>
        <linearGradient id="a4-wall" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#f3d9b6" /><stop offset="1" stopColor="#e6bd8a" /></linearGradient>
        <clipPath id="a4-canvas"><rect x={cL} y={cT} width={cR - cL} height={cB - cT} /></clipPath>
        <radialGradient id="a4-lamp"><stop offset="0" stopColor="#ffd98a" stopOpacity={0.8} /><stop offset="1" stopColor="#ffd98a" stopOpacity={0} /></radialGradient>
      </defs>
      <rect width={1920} height={1080} fill="url(#a4-wall)" />
      {/* floor */}
      <polygon points="0,820 1920,820 1920,1080 0,1080" fill="#b98152" filter="url(#wc-wash)" />
      {[0, 1, 2, 3, 4, 5, 6, 7].map((i) => <line key={i} x1={i * 280 - 40} y1={820} x2={i * 340 - 300} y2={1080} stroke="#8d5d36" strokeOpacity={0.45} strokeWidth={3} />)}
      {/* window with warm light */}
      <g filter="url(#wc-edge)">
        <rect x={140} y={170} width={300} height={380} rx={150} fill="#fff1c9" stroke="#8a5f3a" strokeWidth={14} />
        <path d="M290 170 V550 M140 360 H440" stroke="#8a5f3a" strokeWidth={8} />
      </g>
      <polygon points="140,550 440,550 760,980 120,980" fill="#fff0bd" opacity={0.28} style={{ mixBlendMode: "screen" }} />
      {/* shelf */}
      <g filter="url(#wc-edge)">
        <rect x={1500} y={330} width={330} height={14} fill="#8a5f3a" />
        {[["#f48fb1", 1530], ["#90caf9", 1610], ["#a5d6a7", 1690], ["#ffcc80", 1770]].map(([c, x]) => <rect key={String(x)} x={Number(x)} y={270} width={44} height={60} rx={10} fill={String(c)} />)}
        <rect x={1500} y={520} width={330} height={14} fill="#8a5f3a" />
        <circle cx={1580} cy={490} r={30} fill="#6aa86a" /><rect x={1566} y={500} width={28} height={30} fill="#c97b4a" />
      </g>
      {/* lamp glow */}
      <circle cx={1660} cy={180} r={260} fill="url(#a4-lamp)" opacity={lamp} />
      {/* easel + shared canvas */}
      <g filter="url(#wc-edge)">
        <line x1={720} y1={700} x2={660} y2={900} stroke="#8a5f3a" strokeWidth={14} strokeLinecap="round" />
        <line x1={1200} y1={700} x2={1260} y2={900} stroke="#8a5f3a" strokeWidth={14} strokeLinecap="round" />
        <line x1={960} y1={690} x2={960} y2={900} stroke="#8a5f3a" strokeWidth={14} strokeLinecap="round" />
        <rect x={cL - 14} y={cT - 14} width={cR - cL + 28} height={cB - cT + 28} fill="#a9774a" />
        <rect x={cL} y={cT} width={cR - cL} height={cB - cT} fill="#fffaf0" />
      </g>
      <g clipPath="url(#a4-canvas)">
        <rect x={cL} y={cT} width={cR - cL} height={cB - cT} fill="#fff5e0" />
        <rect x={cL} y={cT} width={cR - cL} height={400} fill="#f9d79a" opacity={reveal(frame, 30, 120)} />
        <circle cx={1080} cy={360} r={60} fill="#fff0b8" opacity={reveal(frame, 160, 90)} />
        <path d={`M${cL} 540 Q860 420 1060 520 T${cR} 500 V${cB} H${cL} Z`} fill="#a9cf86" opacity={reveal(frame, 140, 120)} />
        <path d={`M${cL} 610 Q900 540 1100 620 T${cR} 590 V${cB} H${cL} Z`} fill="#86bb62" opacity={reveal(frame, 220, 120)} />
        {Array.from({ length: 22 }, (_, i) => (
          <circle key={i} cx={cL + 40 + random(`a4x${i}`) * 560} cy={560 + random(`a4y${i}`) * 120} r={9} fill={["#f48fb1", "#fff4c2", "#b39ddb", "#ffab91"][i % 4]} opacity={reveal(frame, 300 + i * 12, 30)} />
        ))}
        <ellipse cx={850} cy={595} rx={22} ry={26} fill="#d9a066" opacity={reveal(frame, 560, 60)} />
        <ellipse cx={1010} cy={595} rx={22} ry={26} fill="#bcc0cc" opacity={reveal(frame, 590, 60)} />
      </g>
      {/* brushes */}
      <line x1={600} y1={800} x2={mTip.x} y2={mTip.y + 30} stroke="#7a4f2a" strokeWidth={8} strokeLinecap="round" />
      <circle cx={mTip.x} cy={mTip.y + 30} r={8} fill="#7fb0d8" />
      <line x1={1320} y1={800} x2={lTip.x} y2={lTip.y + 30} stroke="#7a4f2a" strokeWidth={8} strokeLinecap="round" />
      <circle cx={lTip.x} cy={lTip.y + 30} r={8} fill="#f08aa8" />
      <Rabbit who="milo" garment={{ kind: "shirt", color: "#f0a190" }} x={560} y={985} scale={1.15} mature facing={0.8} mood="happy" frame={frame} tilt={Math.sin(frame / 40) * 1.5} />
      <Rabbit who="luna" garment={{ kind: "vest", color: "#4f9c9a" }} x={1360} y={985} scale={1.15} mature facing={-0.8} mood="happy" frame={frame} tilt={-Math.sin(frame / 44) * 1.5} />
      {[0, 1, 2, 3].map((i) => <Sparkle key={i} x={900 + i * 40 + (i % 2) * 60} y={780} frame={frame} i={i} />)}
      <PaperOverlay />
    </SceneSVG>
  );
};
