import React from "react";
import { interpolate, random, useCurrentFrame } from "remotion";
import { Rabbit } from "../art/Rabbit";
import { Cloud, Drifters, FairyLights, GrassBlades, Hill, LightRays, PaperOverlay, SceneSVG, ScatterFlowers, Sky, Sun, sagString } from "../art/primitives";

const quad = (t: number, p0: [number, number], c: [number, number], p1: [number, number]): [number, number] => [
  (1 - t) * (1 - t) * p0[0] + 2 * (1 - t) * t * c[0] + t * t * p1[0],
  (1 - t) * (1 - t) * p0[1] + 2 * (1 - t) * t * c[1] + t * t * p1[1],
];

const Wedding: React.FC<{ frame: number }> = ({ frame }) => {
  const pts: [number, number][] = [];
  for (let i = 0; i < 9; i++) pts.push([780 + (random(`w1${i}`) - 0.5) * 20, 880 - i * 40]);
  for (let i = 0; i < 28; i++) pts.push(quad(i / 27, [780, 560], [960, 360], [1140, 560]));
  for (let i = 0; i < 9; i++) pts.push([1140 + (random(`w2${i}`) - 0.5) * 20, 880 - i * 40]);
  const l = sagString(80, 360, 800, 530, 110, 9);
  const r = sagString(1120, 530, 1840, 360, 110, 9);
  const m = sagString(790, 575, 1130, 575, 60, 5);
  return (
    <g>
      <Sky id="a3-sky" stops={["#f4b266", "#fbd6a0", "#fdeccb"]} />
      <Sun id="a3-sun" x={330} y={650} r={72} color="#ffe2b0" glow="#ff9f4a" />
      <Cloud x={((frame * 0.2 + 600) % 2300) - 200} y={200} s={1.1} color="#ffe3c2" opacity={0.6} />
      <Hill y={650} amp={40} color="#c5d49a" seed={2} opacity={0.9} />
      <Hill y={740} amp={34} color="#9cc274" seed={6} />
      <rect y={820} width={1920} height={300} fill="#86b862" filter="url(#wc-wash)" />
      <GrassBlades frame={frame} count={200} yMin={820} yMax={1040} colors={["#6fa24b", "#8cc063", "#5d9140"]} seed="a3g" />
      <ScatterFlowers frame={frame} count={34} yMin={850} yMax={1000} seed="a3f" colors={["#f48fb1", "#fff4c2", "#ffffff"]} />
      {/* arch */}
      <g filter="url(#wc-edge)">
        <path d="M780 890 L780 560 Q960 360 1140 560 L1140 890" stroke="#c9a77a" strokeWidth={18} fill="none" strokeLinecap="round" />
        {pts.map(([px, py], i) => (
          <g key={i}>
            <ellipse cx={px - 14} cy={py + 6} rx={14} ry={7} fill="#7fae5a" transform={`rotate(${-30 + (i % 5) * 15} ${px} ${py})`} />
            <circle cx={px} cy={py} r={13 + (i % 4) * 4} fill={["#f7b6c8", "#ffffff", "#ffd3b0", "#f48fb1"][i % 4]} opacity={0.93} />
          </g>
        ))}
      </g>
      <FairyLights frame={frame} path={l.path} points={l.pts} />
      <FairyLights frame={frame + 5} path={r.path} points={r.pts} />
      <FairyLights frame={frame + 9} path={m.path} points={m.pts} />
      <Rabbit who="milo" garment={{ kind: "suit", color: "#868991" }} x={875} y={915} scale={0.95} wedding facing={0.9} mood="calm" frame={frame} />
      <Rabbit who="luna" garment={{ kind: "dress", color: "#fff" }} x={1045} y={915} scale={0.95} wedding facing={-0.9} mood="calm" frame={frame} />
      <Drifters frame={frame} count={46} seed="a3p" colors={["#f7c1d0", "#ffffff", "#ffd9b8"]} size={8} speed={0.6} wind={0.4} />
    </g>
  );
};

const Burrow: React.FC<{ frame: number }> = ({ frame }) => {
  const glow = 0.75 + 0.25 * Math.sin(frame / 16);
  const win = (x: number, y: number) => (
    <g>
      <circle cx={x} cy={y} r={120} fill="#ffcf70" opacity={0.28 * glow} filter="url(#wc-blur)" />
      <circle cx={x} cy={y} r={58} fill="#6b4a2c" />
      <circle cx={x} cy={y} r={48} fill="#ffe49a" opacity={0.75 + 0.25 * glow} />
      <path d={`M${x - 48} ${y} H${x + 48} M${x} ${y - 48} V${y + 48}`} stroke="#6b4a2c" strokeWidth={5} />
    </g>
  );
  return (
    <g>
      <Sky id="a3b-sky" stops={["#f1a860", "#f9cd94", "#fde3b8"]} />
      <Sun id="a3b-sun" x={1600} y={600} r={64} color="#ffdcae" glow="#ff9440" />
      <Hill y={680} amp={36} color="#bdd08f" seed={7} opacity={0.9} />
      <path d="M180 900 Q220 420 960 400 Q1700 420 1740 900 Z" fill="#8fbf6a" filter="url(#wc-wash)" />
      <path d="M300 880 Q340 520 960 500 Q1580 520 1620 880 Z" fill="#a3cb78" opacity={0.6} filter="url(#wc-wash)" />
      <rect y={870} width={1920} height={260} fill="#86b862" filter="url(#wc-wash)" />
      <path d="M900 860 L1020 860 L1160 1090 L760 1090 Z" fill="#e7d2a6" opacity={0.9} filter="url(#wc-edge)" />
      {win(690, 700)}
      {win(1230, 700)}
      <g filter="url(#wc-edge)">
        <circle cx={960} cy={740} r={118} fill="#6b4a2c" />
        <circle cx={960} cy={740} r={104} fill="#5d9a5a" />
        <path d="M900 740 H1020 M960 650 V830" stroke="#4a7d48" strokeWidth={4} opacity={0.6} />
        <circle cx={1010} cy={752} r={8} fill="#f1c24d" />
      </g>
      <rect x={1330} y={380} width={70} height={110} rx={10} fill="#8a5f3a" filter="url(#wc-edge)" />
      <GrassBlades frame={frame} count={150} yMin={870} yMax={1040} colors={["#6fa24b", "#8cc063", "#5d9140"]} seed="a3bg" />
      <ScatterFlowers frame={frame} count={44} yMin={870} yMax={1040} seed="a3bf" colors={["#f48fb1", "#fff4c2", "#b39ddb", "#ffab91"]} />
      <Rabbit who="milo" x={850} y={950} scale={0.8} facing={0.4} mood="happy" frame={frame} />
      <Rabbit who="luna" x={1070} y={950} scale={0.8} facing={-0.4} mood="happy" frame={frame} />
      <Drifters frame={frame} count={22} seed="a3ff" colors={["#ffe58a"]} size={4} speed={0.3} rise wind={0.3} />
    </g>
  );
};

/** Act 3 - Marriage & Settling Down: wedding arch -> cozy burrow home. */
export const Act3Wedding: React.FC = () => {
  const frame = useCurrentFrame();
  const toHome = interpolate(frame, [330, 450], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  return (
    <SceneSVG>
      <g><Wedding frame={frame} /></g>
      <g opacity={toHome}><Burrow frame={frame} /></g>
      <LightRays frame={frame} color="#ffd9a0" opacity={0.13} originX={1700} />
      <PaperOverlay />
    </SceneSVG>
  );
};
