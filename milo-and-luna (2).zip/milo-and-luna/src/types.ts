export type EntryStatus = "planned" | "submitted" | "done" | "failed";

export type ManifestEntry = {
  id: string;
  type: "image" | "video";
  stage: "characters" | "keyframes" | "videos";
  act: string | null;
  shot: number | null;
  prompt: string;
  negativePrompt: string;
  model: string | null;
  durationSec: number | null;
  actualDurationSec: number | null;
  referenceIds: string[];
  startImageId: string | null;
  status: EntryStatus;
  jobId: string | null;
  outputPath: string; // relative to project root, e.g. public/scenes/act1-shot1.mp4
  createdAt: string | null;
  finishedAt: string | null;
  error: string | null;
};

export type Manifest = {
  version: number;
  project: string;
  fps: number;
  entries: ManifestEntry[];
};

export type FilmProps = {
  showCaptions: boolean;
  forcePlaceholders: boolean;
  withAudio: boolean;
};
