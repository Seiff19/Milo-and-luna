import raw from "../assets-manifest.json";
import type { Manifest, ManifestEntry } from "./types";

export const manifest = raw as unknown as Manifest;

/** All video shots for an act, ordered by shot number. */
export const shotsForAct = (actId: string): ManifestEntry[] =>
  manifest.entries
    .filter((e) => e.type === "video" && e.act === actId)
    .sort((a, b) => (a.shot ?? 0) - (b.shot ?? 0));

/** public/scenes/x.mp4 -> scenes/x.mp4 (for staticFile). */
export const toPublicPath = (outputPath: string): string => outputPath.replace(/^public\//, "");
