import React from "react";
import { AbsoluteFill, Audio, interpolate, Sequence, staticFile, useCurrentFrame } from "remotion";
import { ACTS, AUDIO, END_FADE, FADE, TOTAL_FRAMES, type ActConfig, type ActId } from "./config";
import type { FilmProps } from "./types";
import { Captions } from "./components/Captions";
import { CameraMove } from "./components/Camera";
import { ActLengthContext, ClipLayer } from "./components/ClipLayer";
import { Act1Meadow } from "./scenes/Act1Meadow";
import { Act2Oak } from "./scenes/Act2Oak";
import { Act3Wedding } from "./scenes/Act3Wedding";
import { Act4Studio } from "./scenes/Act4Studio";
import { Act5Loss } from "./scenes/Act5Loss";

const PLACEHOLDERS: Record<ActId, React.FC> = {
  act1: Act1Meadow,
  act2: Act2Oak,
  act3: Act3Wedding,
  act4: Act4Studio,
  act5: Act5Loss,
};

const ActShell: React.FC<{ act: ActConfig; index: number; length: number; forcePlaceholders: boolean }> = ({ act, index, length, forcePlaceholders }) => {
  const frame = useCurrentFrame(); // local to this act's Sequence
  const Placeholder = PLACEHOLDERS[act.id];
  const opacity = index === 0 ? 1 : interpolate(frame, [0, FADE], [0, 1], { extrapolateRight: "clamp" });
  return (
    <AbsoluteFill style={{ opacity }}>
      <CameraMove camera={act.camera} length={length}>
        <Placeholder />
        <ActLengthContext.Provider value={length}>
          <ClipLayer actId={act.id} enabled={!forcePlaceholders} />
        </ActLengthContext.Provider>
      </CameraMove>
    </AbsoluteFill>
  );
};

const volumeAt = (f: number): number => {
  const fadeIn = interpolate(f, [0, AUDIO.fadeInFrames], [0, 1], { extrapolateRight: "clamp" });
  // Act 5: long, gentle fade-out
  const fadeOut = interpolate(f, [AUDIO.fadeOutFrom, AUDIO.fadeOutTo], [1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  return AUDIO.baseVolume * fadeIn * fadeOut;
};

export const Film: React.FC<FilmProps> = ({ showCaptions, forcePlaceholders, withAudio }) => {
  const frame = useCurrentFrame();
  const endFade = interpolate(frame, [TOTAL_FRAMES - END_FADE, TOTAL_FRAMES], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  return (
    <AbsoluteFill style={{ backgroundColor: "#1b1f2a" }}>
      {ACTS.map((act, i) => {
        // Every act after the first starts FADE frames early and fades in over the previous act's tail.
        const from = i === 0 ? act.from : act.from - FADE;
        const length = act.to - from;
        return (
          <Sequence key={act.id} from={from} durationInFrames={length} name={`${act.id} - ${act.title}`}>
            <ActShell act={act} index={i} length={length} forcePlaceholders={forcePlaceholders} />
          </Sequence>
        );
      })}
      {showCaptions && <Captions />}
      <AbsoluteFill style={{ backgroundColor: "#0f1420", opacity: endFade, pointerEvents: "none" }} />
      {withAudio && <Audio src={staticFile(AUDIO.src)} volume={volumeAt} />}
    </AbsoluteFill>
  );
};
