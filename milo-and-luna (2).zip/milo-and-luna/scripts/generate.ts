/**
 * Higgsfield generation pipeline.
 *
 *   npx tsx scripts/generate.ts                    DRY RUN (default): prints the plan, makes no network calls
 *   npx tsx scripts/generate.ts --execute          really submit jobs (this spends credits)
 *
 * Options:
 *   --stage characters|keyframes|videos|all   (default: all, run in that order)
 *   --act act1..act5                           only entries for one act
 *   --only <entry-id>                          a single entry (e.g. vid-act1-shot1)
 *   --max <n>                                  stop after n entries (cheap smoke test: --max 1)
 *   --force                                    redo entries already marked done
 *   --concurrency <n>                          parallel jobs (default 2)
 *   --mode api|cli                             overrides HIGGSFIELD_MODE
 *   --poll <sec> --timeout <sec>               polling interval (default 8) / per-job timeout (default 900)
 *
 * Progress is saved to assets-manifest.json after every state change, so it is safe to Ctrl+C and resume.
 */
import "dotenv/config";
import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { createProvider, modelFor, type Provider } from "./higgsfield-adapter";

type Entry = {
  id: string; type: "image" | "video"; stage: string; act: string | null; shot: number | null;
  prompt: string; negativePrompt: string; model: string | null; durationSec: number | null; actualDurationSec: number | null;
  referenceIds: string[]; startImageId: string | null; status: "planned" | "submitted" | "done" | "failed";
  jobId: string | null; outputPath: string; createdAt: string | null; finishedAt: string | null; error: string | null;
};
type Manifest = { entries: Entry[]; [k: string]: unknown };

const MANIFEST = path.resolve("assets-manifest.json");
const argv = process.argv.slice(2);
const flag = (n: string) => argv.includes(`--${n}`);
const opt = (n: string, d = "") => { const i = argv.indexOf(`--${n}`); return i >= 0 && argv[i + 1] ? argv[i + 1] : d; };

const EXECUTE = flag("execute") && !flag("dry-run");
const STAGES = ["characters", "keyframes", "videos"];
const stageArg = opt("stage", "all");
const actArg = opt("act");
const onlyArg = opt("only");
const maxArg = Number(opt("max", "0")) || Infinity;
const FORCE = flag("force");
const CONCURRENCY = Math.max(1, Number(opt("concurrency", "2")));
const POLL_MS = Number(opt("poll", "8")) * 1000;
const TIMEOUT_MS = Number(opt("timeout", "900")) * 1000;
const MODE = opt("mode", process.env.HIGGSFIELD_MODE || "api");

const load = (): Manifest => JSON.parse(fs.readFileSync(MANIFEST, "utf8"));
const save = (m: Manifest) => { fs.writeFileSync(MANIFEST + ".tmp", JSON.stringify(m, null, 2) + "\n"); fs.renameSync(MANIFEST + ".tmp", MANIFEST); };
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const exists = (e: Entry) => fs.existsSync(path.resolve(e.outputPath));

const probeDuration = (file: string): number | null => {
  const r = spawnSync("ffprobe", ["-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", file], { encoding: "utf8" });
  const d = parseFloat(r.stdout);
  return Number.isFinite(d) ? d : null;
};

function select(m: Manifest): Entry[] {
  return m.entries
    .filter((e) => (stageArg === "all" || e.stage === stageArg) && (!actArg || e.act === actArg) && (!onlyArg || e.id === onlyArg))
    .filter((e) => FORCE || e.status !== "done" || !exists(e))
    .sort((a, b) => STAGES.indexOf(a.stage) - STAGES.indexOf(b.stage));
}

/* ------------------------------ dry run ------------------------------ */
function dryRun(m: Manifest) {
  const todo = select(m).slice(0, maxArg);
  const imgModel = modelFor("image") || "<set HIGGSFIELD_IMAGE_MODEL>";
  const vidModel = modelFor("video") || "<set HIGGSFIELD_VIDEO_MODEL>";
  console.log("\n=== DRY RUN - no network calls, nothing is spent ===\n");
  for (const e of todo) {
    const deps = [...e.referenceIds, e.startImageId].filter(Boolean).join(", ") || "-";
    console.log(`${e.id.padEnd(22)} ${e.type.padEnd(5)} ${e.stage.padEnd(10)} model=${e.type === "image" ? imgModel : vidModel}${e.durationSec ? ` ${e.durationSec}s` : ""}`);
    console.log(`   needs: ${deps}\n   out:   ${e.outputPath}\n   prompt: ${e.prompt.slice(0, 150)}${e.prompt.length > 150 ? "…" : ""}\n`);
  }
  const imgs = todo.filter((e) => e.type === "image").length;
  const vids = todo.filter((e) => e.type === "video");
  const secs = vids.reduce((a, e) => a + (e.durationSec ?? 0), 0);
  console.log(`Plan: ${imgs} images + ${vids.length} videos (${secs}s of footage).`);
  const ci = Number(process.env.HIGGSFIELD_CREDITS_PER_IMAGE), cv = Number(process.env.HIGGSFIELD_CREDITS_PER_VIDEO_SECOND);
  if (process.env.HIGGSFIELD_CREDITS_PER_IMAGE && process.env.HIGGSFIELD_CREDITS_PER_VIDEO_SECOND)
    console.log(`Estimated cost: ${imgs * ci + secs * cv} credits (from your .env rates).`);
  else console.log("Estimated cost: unknown - set HIGGSFIELD_CREDITS_PER_IMAGE / _PER_VIDEO_SECOND in .env to see it.");
  const problems: string[] = [];
  if (MODE === "api") for (const k of ["HIGGSFIELD_API_KEY", "HIGGSFIELD_API_BASE", "HIGGSFIELD_SUBMIT_IMAGE_PATH", "HIGGSFIELD_SUBMIT_VIDEO_PATH", "HIGGSFIELD_STATUS_PATH"]) if (!process.env[k]) problems.push(k);
  if (!process.env.HIGGSFIELD_IMAGE_MODEL) problems.push("HIGGSFIELD_IMAGE_MODEL");
  if (!process.env.HIGGSFIELD_VIDEO_MODEL) problems.push("HIGGSFIELD_VIDEO_MODEL");
  console.log(problems.length ? `\nBefore --execute, set in .env: ${problems.join(", ")}` : "\n.env looks complete.");
  console.log("Tip: first run `--execute --max 1 --stage characters` to test one image before the full batch.");
  console.log("\nRe-run with --execute to submit.\n");
}

/* ------------------------------ execute ------------------------------ */
async function runOne(m: Manifest, e: Entry, provider: Provider) {
  const byId = new Map(m.entries.map((x) => [x.id, x]));
  const need = [...e.referenceIds, e.startImageId].filter(Boolean) as string[];
  for (const id of need) {
    const dep = byId.get(id);
    if (!dep || dep.status !== "done" || !exists(dep)) throw new Error(`dependency not ready: ${id} (run earlier stages first)`);
  }
  const model = modelFor(e.type);
  if (!model) throw new Error(`set HIGGSFIELD_${e.type === "image" ? "IMAGE" : "VIDEO"}_MODEL in .env`);

  if (!e.jobId || e.status !== "submitted") {
    e.model = model; e.status = "submitted"; e.createdAt = new Date().toISOString(); e.error = null;
    const { jobId } = await provider.submit({
      kind: e.type, prompt: e.prompt, negativePrompt: e.negativePrompt, model, aspectRatio: "16:9",
      durationSec: e.durationSec ?? undefined,
      startImagePath: e.startImageId ? path.resolve(byId.get(e.startImageId)!.outputPath) : undefined,
      referenceImagePaths: e.referenceIds.map((id) => path.resolve(byId.get(id)!.outputPath)),
    });
    e.jobId = jobId; save(m);
    console.log(`[submit] ${e.id} -> job ${jobId}`);
  } else console.log(`[resume] ${e.id} job ${e.jobId}`);

  const t0 = Date.now();
  while (Date.now() - t0 < TIMEOUT_MS) {
    await sleep(POLL_MS);
    const s = await provider.poll(e.jobId!, e.type);
    if (s.state === "failed") throw new Error(String(s.error ?? "job failed"));
    if (s.state === "done") {
      if (!s.outputUrl) throw new Error("job done but no output URL found - adjust the mapping in higgsfield-adapter.ts (PLUG IN)");
      await provider.download(s.outputUrl, path.resolve(e.outputPath));
      if (e.type === "video") e.actualDurationSec = probeDuration(path.resolve(e.outputPath));
      e.status = "done"; e.finishedAt = new Date().toISOString(); e.error = null; save(m);
      console.log(`[done]   ${e.id} -> ${e.outputPath}${e.actualDurationSec ? ` (${e.actualDurationSec.toFixed(2)}s)` : ""}`);
      return;
    }
    process.stdout.write(`[wait]   ${e.id} ${s.state}…\r`);
  }
  throw new Error(`timed out after ${TIMEOUT_MS / 1000}s (job ${e.jobId} is still saved; re-run to resume)`);
}

async function execute(m: Manifest) {
  const provider = createProvider(MODE);
  const todo = select(m).slice(0, maxArg);
  console.log(`\n=== EXECUTE (${provider.name}) - ${todo.length} entries, concurrency ${CONCURRENCY} ===\n`);
  for (const stage of STAGES) {
    const batch = todo.filter((e) => e.stage === stage);
    if (!batch.length) continue;
    console.log(`--- stage: ${stage} (${batch.length}) ---`);
    let next = 0;
    const worker = async () => {
      while (next < batch.length) {
        const e = batch[next++];
        try { await runOne(m, e, provider); }
        catch (err) { e.status = "failed"; e.error = String((err as Error).message ?? err); e.finishedAt = new Date().toISOString(); save(m); console.error(`[fail]   ${e.id}: ${e.error}`); }
      }
    };
    await Promise.all(Array.from({ length: CONCURRENCY }, worker));
    if (batch.some((e) => e.status === "failed")) console.warn(`Some ${stage} failed; later stages that depend on them will be skipped with a clear error.`);
  }
  const done = m.entries.filter((e) => e.status === "done").length;
  console.log(`\nFinished. ${done}/${m.entries.length} entries done. Preview with: npm run studio`);
}

(async () => {
  const m = load();
  if (!EXECUTE) return dryRun(m);
  await execute(m);
})().catch((e) => { console.error(`\nError: ${(e as Error).message ?? e}`); process.exit(1); });
