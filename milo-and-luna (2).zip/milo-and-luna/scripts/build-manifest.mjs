// Builds assets-manifest.json (+ prompts/*.md) from the story definition below.
// Edit prompts here, then run:  npm run manifest
// SAFE: this never overwrites progress. Entries already marked submitted/done keep their state.
import fs from "node:fs";

const STYLE =
  "Soft 2D watercolor storybook illustration, gentle wet-on-wet washes, soft blooming edges, visible cold-press paper grain, warm hand-painted feel, no text, no logos, 16:9 composition";
const NEGATIVE =
  "photorealistic, 3D render, CGI, harsh black outlines, text, captions, watermark, extra limbs, deformed rabbit anatomy, off-model characters, changed fur colors, different accessories";

// ---- Canonical character descriptors: paste these VERBATIM into every prompt ----
const MILO =
  "Milo, a male rabbit with warm honey-tan fur, cream belly and muzzle, gentle round dark eyes, a soft kind expression, wearing a light-blue scarf";
const LUNA =
  "Luna, a female rabbit with warm honey-tan fur (a touch lighter and creamier than Milo), cream chest, kind dark eyes with soft lashes, a pink ribbon bow tied on her left ear";

const AGE = {
  young: "as a young bunny: small, round, big-headed, playful proportions",
  teen: "as a young adult rabbit: slimmer, longer ears, thoughtful",
  wedding:
    "as grown rabbits on their wedding day (Milo in a dove-grey suit with a small white flower on the lapel, no scarf for the ceremony; Luna in a white wedding gown with a sheer veil, her pink ribbon still on her ear, holding a small bouquet of pink and white flowers)",
  mature: "as mature rabbits: confident, calm, fur slightly lighter around the muzzle",
};

const OUTFIT = {
  act1: "",
  act2: " Milo also wears a small blue vest and Luna a soft pink cardigan.",
  act3: "",
  act4: " Milo also wears a salmon-pink shirt and Luna a teal vest.",
  act5: " Luna wears her soft pink cardigan; Milo's light-blue scarf is draped nearby.",
};
const DUO = (age) => `${MILO} and ${LUNA}, both drawn ${AGE[age]}`;

// ---- Shots: 5 seconds each -> 4+5+5+5+4 = 23 shots = 115 s ----
const ACTS = [
  {
    id: "act1", title: "Childhood Friendship", age: "young",
    mood: "bright sunlit meadow with dandelions and wildflowers, soft morning golden light, joyful and curious mood",
    shots: [
      ["Wide shot: the two young rabbits meet in the middle of the meadow, noses almost touching, curious", "very slow push-in; dandelion seeds drift past; both rabbits tilt their heads and wiggle their noses"],
      ["Both young rabbits hop side by side through tall grass and wildflowers, mid-hop, joyful", "gentle tracking pan following their hops; grass and flowers sway"],
      ["Close-up: Luna blows a dandelion puff while Milo watches in delight, seeds floating in golden light", "slow drift; dandelion seeds float upward and across the frame"],
      ["The two chase a butterfly across the meadow in golden backlight", "slow pull-back as they hop away toward a glowing horizon"],
    ],
  },
  {
    id: "act2", title: "Learning & Growing Together", age: "teen",
    mood: "large blossoming oak tree on a gentle hill, warm afternoon light, curious and warm mood",
    shots: [
      ["Wide shot: under the big blossoming oak, the two sit close with one large open book", "slow push-in; blossom petals fall gently"],
      ["Medium shot: reading one big book side by side, Luna points at a page, Milo smiles", "subtle drift; a page edge flutters in the breeze"],
      ["Detail: the open book with simple pencil sketches of stars and plants, two small paws pointing at the same line", "very slow tilt down the page; dust motes in warm light"],
      ["They study a tiny leaf together with a small magnifying glass, heads touching", "gentle orbit; dappled light shifts through the leaves"],
      ["Late afternoon: they lean shoulder to shoulder watching sunlight through the blossoms, content", "slow pull-back revealing the whole tree glowing"],
    ],
  },
  {
    id: "act3", title: "Marriage & Settling Down", age: "wedding",
    mood: "golden hour warmth, soft glowing fairy lights, tender and heartfelt",
    shots: [
      ["Meadow wedding: a floral arch of pink and white blossoms strung with warm fairy lights; Milo and Luna stand beneath it facing each other", "slow push-in; fairy lights twinkle; petals drift"],
      ["Close-up: their paws joined beneath the arch, noses nearly touching, petals falling", "very slow drift; shallow soft focus; warm light flares"],
      ["Small woodland friends (a mouse, a hedgehog, songbirds) cheer softly and toss petals as the couple stands under the arch", "gentle pan across the guests; petals in the air"],
      ["Dusk: Milo and Luna walk paw in paw along a flower-lined path toward a cozy hillside burrow home", "slow tracking shot from behind; fireflies begin to appear"],
      ["The cozy burrow home at golden hour: round green door, glowing windows, garden flowers; the couple stand in the doorway", "slow push-in; window light flickers warmly"],
    ],
  },
  {
    id: "act4", title: "Mutual Growth & Partnership", age: "mature",
    mood: "sunlit creative studio inside the burrow, uplifting steady rhythm, warm wooden tones",
    shots: [
      ["Inside the burrow studio, Milo and Luna paint side by side on one large shared canvas", "slow push-in; sunlight slides across the floor"],
      ["Close-up: Luna's brush adds a bright stroke while Milo watches and nods encouragingly", "gentle drift between the two; paint shimmer"],
      ["They hold up a finished painting of their meadow, proud and smiling", "slow pull-back; warm light blooms"],
      ["Luna rests a paw on Milo's shoulder as he hesitates at a blank canvas; he smiles and begins to paint", "slow orbit; soft light"],
      ["Evening: the two hang their paintings along the burrow wall by warm lamplight, content", "slow lateral pan along the wall of paintings"],
    ],
  },
  {
    id: "act5", title: "Sudden Loss", age: "mature",
    mood: "quiet dim twilight burrow room, cool muted desaturated blue-slate tones, very still and tender",
    shots: [
      ["A dim burrow room: one small glowing candle on a table and an empty wooden chair with a light-blue scarf draped over its back; no one else is there", "extremely slow push-in; candle flame flickers softly"],
      ["Luna sits alone beside the candle, ears drooping, gazing at the empty chair, quiet grief", "extremely slow drift; the candle glow breathes"],
      ["Close-up: the candle flame and the long shadow of the empty chair on the wall", "almost still; faint flicker; a few dust motes"],
      ["Luna's paw gently rests on the light-blue scarf draped over the chair, eyes closed, cold blue window light", "nearly still, very slow push-in; slow fade-ready ending"],
    ],
  },
];

const entries = [];
const E = (e) => entries.push({
  model: null, jobId: null, status: "planned", createdAt: null, finishedAt: null,
  error: null, actualDurationSec: null, negativePrompt: NEGATIVE, referenceIds: [], startImageId: null,
  act: null, shot: null, durationSec: null, ...e,
});

// ---- Character sheets (stage "characters") ----
const sheet = (who, ageKey) => {
  const base = who === "milo" ? MILO : LUNA;
  const ageText = ageKey === "young" ? AGE.young : AGE.mature;
  E({
    id: `char-${who}-${ageKey}`, type: "image", stage: "characters",
    prompt: `${STYLE}. Character reference sheet on plain warm cream paper: ${base}, ${ageText}. Show front view, three-quarter view and side view, plus one small gentle-smile expression. Neutral standing pose, full body, consistent proportions.`,
    outputPath: `public/characters/${who}-${ageKey}.png`,
  });
};
sheet("milo", "young"); sheet("luna", "young"); sheet("milo", "adult"); sheet("luna", "adult");

// ---- Keyframes + videos ----
for (const act of ACTS) {
  const sheetAge = act.age === "young" ? "young" : "adult";
  act.shots.forEach(([scene, motion], i) => {
    const n = i + 1;
    const base = `${act.id}-shot${n}`;
    E({
      id: `kf-${base}`, type: "image", stage: "keyframes", act: act.id, shot: n,
      referenceIds: [`char-milo-${sheetAge}`, `char-luna-${sheetAge}`],
      prompt: `${STYLE}. ${DUO(act.age)}.${OUTFIT[act.id]} ${scene}. Setting/mood: ${act.mood}.`,
      outputPath: `public/keyframes/${base}.png`,
    });
    E({
      id: `vid-${base}`, type: "video", stage: "videos", act: act.id, shot: n,
      startImageId: `kf-${base}`, durationSec: 5,
      prompt: `${motion}. Keep the painted watercolor style and both rabbits exactly on-model. Gentle, calm camera, no sudden movement, no morphing, no text. Mood: ${act.mood}.`,
      outputPath: `public/scenes/${base}.mp4`,
    });
  });
}

// ---- Preserve progress from an existing manifest ----
const file = "assets-manifest.json";
let prior = {};
if (fs.existsSync(file)) {
  for (const e of JSON.parse(fs.readFileSync(file, "utf8")).entries ?? []) prior[e.id] = e;
}
const merged = entries.map((e) => {
  const p = prior[e.id];
  return p && p.status !== "planned"
    ? { ...e, status: p.status, jobId: p.jobId, model: p.model, createdAt: p.createdAt, finishedAt: p.finishedAt, error: p.error, actualDurationSec: p.actualDurationSec }
    : e;
});

const manifest = {
  version: 1,
  project: "Milo & Luna",
  fps: 30,
  resolution: { width: 1920, height: 1080 },
  totalFrames: 3450,
  totalSeconds: 115,
  style: STYLE,
  characters: { milo: MILO, luna: LUNA, ages: AGE },
  acts: ACTS.map((a, i) => ({ id: a.id, title: a.title, shots: a.shots.length })),
  entries: merged,
};
fs.writeFileSync(file, JSON.stringify(manifest, null, 2) + "\n");

// ---- Human-readable prompt files ----
fs.mkdirSync("prompts", { recursive: true });
const md = [
  "# Milo & Luna - character consistency kit\n",
  "Paste these descriptors VERBATIM into every prompt. Do not paraphrase them.\n",
  `**Style lock:** ${STYLE}\n`,
  `**Negative prompt:** ${NEGATIVE}\n`,
  `## Milo\n${MILO}\n`,
  `## Luna\n${LUNA}\n`,
  "## Age / outfit variants\n" + Object.entries(AGE).map(([k, v]) => `- **${k}**: ${v}`).join("\n") + "\n",
  "## Workflow\n1. Generate the 4 character sheets (stage `characters`). Review them; regenerate until Milo and Luna look right.\n2. Generate keyframes (stage `keyframes`) using the sheets as reference images.\n3. Animate each keyframe (stage `videos`, image-to-video).\n4. If a character drifts off-model, regenerate that keyframe, not the video.\n",
];
for (const act of ACTS) {
  md.push(`\n## ${act.id} - ${act.title} (${act.shots.length} x 5s)\n`);
  act.shots.forEach(([scene, motion], i) => md.push(`**Shot ${i + 1}** - ${scene}\n- Motion: ${motion}\n`));
}
fs.writeFileSync("prompts/characters-and-keyframes.md", md.join("\n"));
console.log(`Wrote ${file} with ${merged.length} entries (${merged.filter(e=>e.type==="image").length} images, ${merged.filter(e=>e.type==="video").length} videos).`);
