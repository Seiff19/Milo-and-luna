// Procedural ambient piano-ish score for Milo & Luna. No dependencies except ffmpeg.
//   node scripts/make-audio.mjs            -> public/audio/ambient.mp3
//   node scripts/make-audio.mjs --keep-wav -> also keeps the .wav
// Sections follow the film: bright -> warm -> steady -> sparse/minor (Act 5).
import fs from "node:fs";
import { spawnSync } from "node:child_process";

const SR = 44100;
const DUR = 118; // seconds (film is 115s; extra tail for fade)
const N = SR * DUR;
const L = new Float32Array(N), R = new Float32Array(N);

let seed = 20261124;
const rnd = () => { seed |= 0; seed = (seed + 0x6d2b79f5) | 0; let t = Math.imul(seed ^ (seed >>> 15), 1 | seed); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
const hz = (m) => 440 * 2 ** ((m - 69) / 12);

function note(t0, m, dur, vel, { pan = 0.5, attack = 0.006, bright = 1, decay = 1.3 } = {}) {
  const f = hz(m), s0 = Math.floor(t0 * SR);
  const len = Math.min(Math.floor(dur * SR), N - s0);
  if (len <= 0) return;
  const d = decay + Math.max(0, m - 55) * 0.03;
  for (let i = 0; i < len; i++) {
    const t = i / SR;
    const a = Math.min(1, t / attack);
    const rel = Math.min(1, (len - i) / 2400);
    const env = a * rel * Math.exp(-t * d);
    const w =
      Math.sin(2 * Math.PI * f * t) +
      0.45 * bright * Math.sin(2 * Math.PI * f * 2 * t) * Math.exp(-t * 3) +
      0.22 * bright * Math.sin(2 * Math.PI * f * 3 * t) * Math.exp(-t * 5) +
      0.10 * bright * Math.sin(2 * Math.PI * f * 4.01 * t) * Math.exp(-t * 8) +
      0.35 * Math.sin(2 * Math.PI * f * 1.003 * t);
    const v = w * env * vel * 0.22;
    L[s0 + i] += v * (1 - pan) * 2 * 0.5 + v * 0.5 * (1 - pan);
    R[s0 + i] += v * pan * 2 * 0.5 + v * 0.5 * pan;
  }
}

const C = { C: [48, 52, 55, 60, 64, 67], G: [43, 47, 50, 55, 59, 62], Am: [45, 48, 52, 57, 60, 64], F: [41, 45, 48, 53, 57, 60], Em: [40, 47, 52, 55, 59, 64], Dm: [38, 45, 50, 53, 57, 62] };
const SCALE_MAJ = [60, 62, 64, 67, 69, 72, 74, 76];
const SCALE_MIN = [57, 60, 62, 64, 67, 69, 72];

const sections = [
  { from: 0, to: 20, bpm: 76, chords: ["C", "G", "Am", "F"], pat: [0, 2, 3, 2, 4, 2, 3, 2], vel: 0.55, melody: 0.45, scale: SCALE_MAJ, pad: 0.35 },
  { from: 20, to: 45, bpm: 72, chords: ["F", "C", "G", "Am"], pat: [0, 2, 4, 3, 5, 3, 4, 2], vel: 0.55, melody: 0.55, scale: SCALE_MAJ, pad: 0.4 },
  { from: 45, to: 70, bpm: 66, chords: ["C", "Em", "F", "G"], pat: [0, 3, 4, 5], vel: 0.6, melody: 0.7, scale: SCALE_MAJ, pad: 0.55 },
  { from: 70, to: 95, bpm: 84, chords: ["Am", "F", "C", "G"], pat: [0, 2, 3, 4, 3, 2, 4, 2], vel: 0.5, melody: 0.5, scale: SCALE_MAJ, pad: 0.35 },
  { from: 95, to: 118, bpm: 50, chords: ["Am", "F", "Dm", "Am"], pat: [0, 3], vel: 0.38, melody: 0.35, scale: SCALE_MIN, pad: 0.3, last: true },
];

for (const s of sections) {
  const beat = 60 / s.bpm, bar = beat * 4, step = beat / (s.pat.length / 4 >= 1 ? s.pat.length / 4 : 1);
  let bi = 0;
  for (let t = s.from; t < s.to; t += bar, bi++) {
    const ch = C[s.chords[bi % s.chords.length]];
    const fade = s.last ? Math.max(0.15, 1 - (t - s.from) / (s.to - s.from)) : 1;
    // bass + pad
    note(t, ch[0], bar * 1.3, 0.8 * s.vel * fade, { pan: 0.4, decay: 0.5, bright: 0.4 });
    note(t, ch[0] + 12, bar * 1.3, s.pad * fade, { pan: 0.55, attack: 0.9, decay: 0.25, bright: 0.2 });
    note(t, ch[2] + 12, bar * 1.3, s.pad * 0.7 * fade, { pan: 0.45, attack: 1.1, decay: 0.25, bright: 0.2 });
    // arpeggio
    const n = s.pat.length;
    const dt = bar / n;
    for (let k = 0; k < n; k++) {
      const tt = t + k * dt;
      if (tt >= s.to) break;
      note(tt, ch[s.pat[k] % ch.length] + (s.last ? 0 : 12), 2.2, s.vel * fade * (k % 2 ? 0.75 : 1), { pan: 0.35 + 0.3 * rnd() });
    }
    // melody on beats
    for (let b = 0; b < 4; b++) {
      if (rnd() < s.melody * (s.last ? fade : 1)) {
        const m = s.scale[Math.floor(rnd() * s.scale.length)] + (s.last ? 0 : 12);
        note(t + b * beat + (rnd() < 0.3 ? beat / 2 : 0), m, 3, s.vel * 0.9 * fade, { pan: 0.6, bright: 1.2, decay: 1.0 });
      }
    }
  }
}

// simple stereo reverb (parallel combs + allpass)
function reverb(buf, delays, fb, wet) {
  const out = new Float32Array(buf.length);
  for (const d of delays) {
    const line = new Float32Array(d); let p = 0;
    for (let i = 0; i < buf.length; i++) { const y = line[p]; line[p] = buf[i] + y * fb; out[i] += y; p = (p + 1) % d; }
  }
  for (let i = 0; i < buf.length; i++) buf[i] = buf[i] * (1 - wet * 0.4) + (out[i] / delays.length) * wet * 2.2;
}
reverb(L, [1687, 1931, 2293, 2617], 0.82, 0.32);
reverb(R, [1733, 1987, 2341, 2663], 0.82, 0.32);

// normalise + tail fade
let peak = 0;
for (let i = 0; i < N; i++) peak = Math.max(peak, Math.abs(L[i]), Math.abs(R[i]));
const g = 0.8 / (peak || 1), tailStart = (DUR - 5) * SR;
for (let i = 0; i < N; i++) { const f = i > tailStart ? Math.max(0, 1 - (i - tailStart) / (N - tailStart)) : 1; L[i] *= g * f; R[i] *= g * f; }

// write wav
const wav = Buffer.alloc(44 + N * 4);
wav.write("RIFF", 0); wav.writeUInt32LE(36 + N * 4, 4); wav.write("WAVEfmt ", 8); wav.writeUInt32LE(16, 16);
wav.writeUInt16LE(1, 20); wav.writeUInt16LE(2, 22); wav.writeUInt32LE(SR, 24); wav.writeUInt32LE(SR * 4, 28);
wav.writeUInt16LE(4, 32); wav.writeUInt16LE(16, 34); wav.write("data", 36); wav.writeUInt32LE(N * 4, 40);
for (let i = 0; i < N; i++) { wav.writeInt16LE(Math.round(Math.max(-1, Math.min(1, L[i])) * 32767), 44 + i * 4); wav.writeInt16LE(Math.round(Math.max(-1, Math.min(1, R[i])) * 32767), 46 + i * 4); }
fs.mkdirSync("public/audio", { recursive: true });
fs.writeFileSync("public/audio/ambient.wav", wav);
const r = spawnSync("ffmpeg", ["-y", "-loglevel", "error", "-i", "public/audio/ambient.wav", "-codec:a", "libmp3lame", "-q:a", "4", "public/audio/ambient.mp3"]);
if (r.status !== 0) { console.error("ffmpeg failed:", r.stderr?.toString()); process.exit(1); }
if (!process.argv.includes("--keep-wav")) fs.unlinkSync("public/audio/ambient.wav");
console.log("Wrote public/audio/ambient.mp3");
