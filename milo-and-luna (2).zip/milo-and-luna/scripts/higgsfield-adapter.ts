/**
 * Higgsfield adapter - the ONLY file that knows how to talk to Higgsfield.
 *
 * Two transports, chosen by HIGGSFIELD_MODE in .env:
 *   api  -> HTTPS calls using HIGGSFIELD_API_KEY
 *   cli  -> spawns a local CLI (HIGGSFIELD_CLI_CMD) using argument templates
 *
 * I could not verify Higgsfield's real endpoints/payloads/CLI flags from the build
 * environment, so every spot you must confirm is marked "PLUG IN". Search for it.
 */
import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";

export type Kind = "image" | "video";

export type SubmitInput = {
  kind: Kind;
  prompt: string;
  negativePrompt?: string;
  model: string;
  aspectRatio: string; // "16:9"
  durationSec?: number; // video only
  startImagePath?: string; // video: the keyframe to animate (image-to-video)
  referenceImagePaths: string[]; // image: character sheets for consistency
};

export type JobState = "queued" | "running" | "done" | "failed";
export type JobStatus = { state: JobState; outputUrl?: string; error?: string; raw?: unknown };

export interface Provider {
  name: string;
  submit(i: SubmitInput): Promise<{ jobId: string }>;
  poll(jobId: string, kind: Kind): Promise<JobStatus>;
  download(url: string, dest: string): Promise<void>;
}

const env = (k: string, d = ""): string => (process.env[k] ?? d).trim();

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */
const toDataUri = (file: string): string => {
  const ext = path.extname(file).slice(1).toLowerCase() || "png";
  const mime = ext === "jpg" ? "image/jpeg" : `image/${ext}`;
  return `data:${mime};base64,${fs.readFileSync(file).toString("base64")}`;
};

const normaliseState = (s: unknown): JobState => {
  const v = String(s ?? "").toLowerCase();
  if (["done", "completed", "complete", "succeeded", "success", "finished"].includes(v)) return "done";
  if (["failed", "error", "canceled", "cancelled", "nsfw", "rejected"].includes(v)) return "failed";
  if (["queued", "pending", "waiting", "created"].includes(v)) return "queued";
  return "running";
};

// Dig a URL/id out of a few common response shapes. PLUG IN: adjust to the real response.
const pick = (o: any, keys: string[]): any => {
  for (const k of keys) {
    const v = k.split(".").reduce((a, p) => (a == null ? a : a[p]), o);
    if (v != null && v !== "") return v;
  }
  return undefined;
};

/* ------------------------------------------------------------------ */
/* API transport                                                       */
/* ------------------------------------------------------------------ */
class ApiProvider implements Provider {
  name = "higgsfield-api";
  private base = env("HIGGSFIELD_API_BASE").replace(/\/$/, "");
  private key = env("HIGGSFIELD_API_KEY");

  constructor() {
    const missing = ["HIGGSFIELD_API_KEY", "HIGGSFIELD_API_BASE", "HIGGSFIELD_SUBMIT_IMAGE_PATH", "HIGGSFIELD_SUBMIT_VIDEO_PATH", "HIGGSFIELD_STATUS_PATH"].filter((k) => !env(k));
    if (missing.length) throw new Error(`API mode needs these in .env: ${missing.join(", ")}`);
  }

  private headers(): Record<string, string> {
    // PLUG IN: change if Higgsfield uses a different header/scheme.
    const header = env("HIGGSFIELD_AUTH_HEADER", "Authorization");
    const scheme = env("HIGGSFIELD_AUTH_SCHEME", "Bearer");
    return { "Content-Type": "application/json", [header]: scheme ? `${scheme} ${this.key}` : this.key };
  }

  /** PLUG IN: map our neutral input to Higgsfield's request body. */
  private buildBody(i: SubmitInput): Record<string, unknown> {
    return {
      model: i.model, // e.g. the image/video model ID from your account
      prompt: i.prompt,
      negative_prompt: i.negativePrompt,
      aspect_ratio: i.aspectRatio,
      ...(i.kind === "video"
        ? { duration: i.durationSec, image: i.startImagePath ? toDataUri(i.startImagePath) : undefined }
        : { reference_images: i.referenceImagePaths.map(toDataUri) }),
    };
  }

  async submit(i: SubmitInput): Promise<{ jobId: string }> {
    const p = i.kind === "image" ? env("HIGGSFIELD_SUBMIT_IMAGE_PATH") : env("HIGGSFIELD_SUBMIT_VIDEO_PATH");
    const res = await fetch(`${this.base}${p}`, { method: "POST", headers: this.headers(), body: JSON.stringify(this.buildBody(i)) });
    const text = await res.text();
    if (!res.ok) throw new Error(`submit ${res.status}: ${text.slice(0, 400)}`);
    const json = JSON.parse(text);
    const jobId = pick(json, ["id", "job_id", "request_id", "data.id", "data.job_id"]); // PLUG IN
    if (!jobId) throw new Error(`no job id in response: ${text.slice(0, 400)}`);
    return { jobId: String(jobId) };
  }

  async poll(jobId: string): Promise<JobStatus> {
    const url = `${this.base}${env("HIGGSFIELD_STATUS_PATH").replace("{jobId}", encodeURIComponent(jobId))}`;
    const res = await fetch(url, { headers: this.headers() });
    const text = await res.text();
    if (!res.ok) throw new Error(`status ${res.status}: ${text.slice(0, 400)}`);
    const json = JSON.parse(text);
    const state = normaliseState(pick(json, ["status", "state", "data.status"])); // PLUG IN
    const outputUrl = pick(json, ["output_url", "result.url", "video.url", "image.url", "data.url", "outputs.0.url", "output.0"]); // PLUG IN
    return { state, outputUrl, error: pick(json, ["error", "error.message", "message"]), raw: json };
  }

  async download(url: string, dest: string): Promise<void> {
    const res = await fetch(url);
    if (!res.ok) throw new Error(`download ${res.status}`);
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.writeFileSync(dest, Buffer.from(await res.arrayBuffer()));
  }
}

/* ------------------------------------------------------------------ */
/* CLI transport                                                       */
/* ------------------------------------------------------------------ */
class CliProvider implements Provider {
  name = "higgsfield-cli";
  private cmd = env("HIGGSFIELD_CLI_CMD", "higgsfield");

  private run(template: string, tokens: Record<string, string>): any {
    // Split the TEMPLATE first, then substitute, so prompts with spaces stay one argument (no shell).
    const args = template.split(/\s+/).filter(Boolean).map((a) => a.replace(/\{(\w+)\}/g, (_, k) => tokens[k] ?? ""));
    const r = spawnSync(this.cmd, args, { encoding: "utf8", maxBuffer: 64 * 1024 * 1024 });
    if (r.error) throw new Error(`cannot run '${this.cmd}': ${r.error.message}`);
    if (r.status !== 0) throw new Error(`${this.cmd} exited ${r.status}: ${(r.stderr || r.stdout).slice(0, 400)}`);
    try { return JSON.parse(r.stdout); } catch { throw new Error(`CLI did not print JSON: ${r.stdout.slice(0, 300)}`); }
  }

  async submit(i: SubmitInput): Promise<{ jobId: string }> {
    const tpl = i.kind === "image" ? env("HIGGSFIELD_CLI_SUBMIT_IMAGE_TEMPLATE") : env("HIGGSFIELD_CLI_SUBMIT_VIDEO_TEMPLATE");
    if (!tpl) throw new Error("Set HIGGSFIELD_CLI_SUBMIT_*_TEMPLATE in .env");
    const json = this.run(tpl, {
      model: i.model, prompt: i.prompt, negative: i.negativePrompt ?? "", aspect: i.aspectRatio,
      duration: String(i.durationSec ?? ""), startImage: i.startImagePath ?? "", refs: i.referenceImagePaths.join(","),
    });
    const jobId = pick(json, ["id", "job_id", "request_id"]); // PLUG IN
    if (!jobId) throw new Error(`no job id in CLI output: ${JSON.stringify(json).slice(0, 300)}`);
    return { jobId: String(jobId) };
  }

  async poll(jobId: string): Promise<JobStatus> {
    const json = this.run(env("HIGGSFIELD_CLI_STATUS_TEMPLATE", "status {jobId} --json"), { jobId });
    return {
      state: normaliseState(pick(json, ["status", "state"])),
      outputUrl: pick(json, ["output_url", "url", "result.url", "outputs.0.url"]), // PLUG IN
      error: pick(json, ["error", "message"]),
      raw: json,
    };
  }

  async download(url: string, dest: string): Promise<void> {
    const res = await fetch(url);
    if (!res.ok) throw new Error(`download ${res.status}`);
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.writeFileSync(dest, Buffer.from(await res.arrayBuffer()));
  }
}

export const createProvider = (mode: string): Provider => (mode === "cli" ? new CliProvider() : new ApiProvider());
export const modelFor = (kind: Kind): string => env(kind === "image" ? "HIGGSFIELD_IMAGE_MODEL" : "HIGGSFIELD_VIDEO_MODEL");
