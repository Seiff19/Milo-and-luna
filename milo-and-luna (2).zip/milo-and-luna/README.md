# Milo & Luna — a 115-second watercolor short

Remotion (React + TypeScript) project, 1920×1080 @ 30 fps, 3450 frames, five acts.
Works **out of the box** with illustrated SVG placeholder scenes and a generated ambient score.
Higgsfield clips are layered on top as you generate them.

```
assets-manifest.json   every planned generation: prompt, model, status, job id, output path
prompts/               character-consistency kit + per-shot prompts (human readable)
scripts/               build-manifest, generate (Higgsfield), higgsfield-adapter, make-audio
src/                   Remotion project (Film, scenes, art, captions, camera)
public/audio/          ambient.mp3 (already generated)
public/characters|keyframes|scenes/   generated assets land here
```

## 1. Install

Requirements: Node 18+ (22 recommended), ffmpeg + ffprobe on your PATH.

```bash
npm install
npx remotion versions      # if it warns about mismatched versions: npm run upgrade
```

## Look reference

`reference/storyboard.jpg` is your storyboard. Character design follows it: both rabbits are warm honey-tan
(Luna a touch lighter), Milo wears a light-blue scarf, Luna a pink ribbon bow on her left ear. Outfits by act:
blue vest / pink cardigan (Act 2), grey suit / white gown (Act 3), salmon shirt / teal vest (Act 4),
pink cardigan with the blue scarf left on the chair (Act 5). If your Higgsfield model accepts a style image,
you can add it manually as an extra reference; the storyboard contains text labels, so crop a single panel first.

## 2. Preview (no Higgsfield needed)

```bash
npm run studio
```

Pick composition **MiloAndLuna**. In the Props panel you can toggle `showCaptions`,
`withAudio`, and `forcePlaceholders` (ignore generated clips and show the illustrated scenes).
Act timing: 0–600 · 600–1350 · 1350–2100 · 2100–2850 · 2850–3450 (edit `src/config.ts`).
Cheap placeholder render for review: `npm run render:placeholders`.

## 3. Generate with Higgsfield

I could not verify Higgsfield's real endpoints or CLI flags, so the adapter has clearly marked
`PLUG IN` spots. Do these once:

1. `cp .env.example .env`
2. Fill in `HIGGSFIELD_MODE` (`api` or `cli`) and either
   - **api**: `HIGGSFIELD_API_KEY`, `HIGGSFIELD_API_BASE`, the three endpoint paths, auth header, or
   - **cli**: `HIGGSFIELD_CLI_CMD` and the three argument templates (the CLI must print JSON).
3. Set `HIGGSFIELD_IMAGE_MODEL` and `HIGGSFIELD_VIDEO_MODEL` from your Higgsfield account/docs.
4. Open `scripts/higgsfield-adapter.ts`, search for `PLUG IN`, and match `buildBody`, the job-id
   field and the output-URL field to the real responses.
5. (Optional) set `HIGGSFIELD_CREDITS_PER_IMAGE` / `_PER_VIDEO_SECOND` so the dry run shows a cost.

**Dry run first (default, spends nothing, makes no network calls):**

```bash
npm run generate                       # whole plan
npm run generate -- --act act1         # one act
```

**Smoke test one image, then go stage by stage:**

```bash
npm run generate:run -- --stage characters --max 1
npm run generate:run -- --stage characters       # 4 character sheets - CHECK THEM before continuing
npm run generate:run -- --stage keyframes        # 23 keyframes, using the sheets as references
npm run generate:run -- --stage videos --act act1
npm run generate:run -- --stage videos           # the rest
```

Useful flags: `--only vid-act2-shot3`, `--force` (redo), `--concurrency 3`, `--mode cli`,
`--timeout 1200`. Progress is saved after every state change; Ctrl+C and re-run to resume.
Failed entries show their error in `assets-manifest.json`; re-running retries them.

**Consistency rules** (details in `prompts/characters-and-keyframes.md`):
use the canonical Milo/Luna descriptors verbatim, regenerate off-model **keyframes** rather than
videos, and keep each act's keyframes in the same age/outfit variant.

Each act is built from 5-second shots (4+5+5+5+4 = 23). Remotion stretches the clips
evenly to fit the act, using the real clip length recorded by ffprobe. A shot is used only when its
manifest status is `done`; any missing shot falls back to the illustrated placeholder, so you can
preview a half-finished film at any time. Editing prompts: change `scripts/build-manifest.mjs`, run
`npm run manifest` (existing progress is preserved).

## 4. Audio

`public/audio/ambient.mp3` is a procedural piano-style score (bright → warm → steady → sparse
and minor in Act 5). Remotion fades it in over 2 s and **fades it out across Act 5**
(frame 2850 → 3420, see `AUDIO` in `src/config.ts`). Regenerate or change it with `npm run audio`.
To use your own music, replace the file (keep the name) or change `AUDIO.src`.

## 5. Render

```bash
npm run typecheck
npm run render                 # -> out/milo-and-luna.mp4 (H.264, CRF 18, AAC audio)
```

Higher quality / smaller files: `npx remotion render src/index.ts MiloAndLuna out/film.mp4 --crf=16`.
Memory trouble on the SVG filters: `--concurrency=2`. Expect a longer render than typical because
the placeholder scenes use SVG displacement filters; generated clips render much faster.

**ffmpeg checks:**

```bash
ffprobe -v error -show_entries format=duration:stream=codec_name,width,height,r_frame_rate -of default=nw=1 out/milo-and-luna.mp4
# expect ~115.0 s, h264 1920x1080 30/1, plus an aac audio stream

ffmpeg -i out/milo-and-luna.mp4 -af volumedetect -f null - 2>&1 | grep -E "mean|max"
ffmpeg -ss 110 -i out/milo-and-luna.mp4 -t 5 -af astats -f null - 2>&1 | grep -m3 "RMS level"   # should be quiet near the end
```

## Notes and limits

- Not yet run on a machine with Remotion installed; I checked syntax and the generation script's
  dry-run and credential checks only. If `npm run typecheck` or Studio reports something, send me the message.
- Act 3's "wedding → burrow" transition happens inside the scene (crossfade around local frames 330–450).
- Act 5 uses a very slow camera move (scale 1.02 → 1.07) and a desaturated blue-slate grade.
